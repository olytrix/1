/**
 * Lười Auto Login - Content Script
 * Tự động điền email + password + OTP và bấm Sign In
 * Chỉ chạy trên cryptolinkforearn.com
 */

(function () {
  "use strict";

  let alreadyRan = false;

  function setNativeValue(element, value) {
    const lastValue = element.value;
    element.value = value;

    const tracker = element._valueTracker;
    if (tracker) {
      tracker.setValue(lastValue);
    }

    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
  }

  function findEmailInput() {
    return (
      document.querySelector('input[name="email"]') ||
      document.querySelector('input[type="email"]') ||
      document.querySelector('input[placeholder*="email" i]') ||
      document.querySelector('input[placeholder*="Email" i]') ||
      document.querySelector('input[id*="email" i]') ||
      document.querySelector('input[autocomplete="email"]') ||
      document.querySelector('input[autocomplete="username"]')
    );
  }

  function findPasswordInput() {
    return (
      document.querySelector('input[name="password"]') ||
      document.querySelector('input[type="password"]') ||
      document.querySelector('input[placeholder*="password" i]') ||
      document.querySelector('input[placeholder*="mật khẩu" i]') ||
      document.querySelector('input[id*="password" i]') ||
      document.querySelector('input[autocomplete="current-password"]')
    );
  }

  function findOtpInput() {
    return (
      document.querySelector('input[name="otp"]') ||
      document.querySelector('input[name="code"]') ||
      document.querySelector('input[name="2fa"]') ||
      document.querySelector('input[placeholder*="otp" i]') ||
      document.querySelector('input[placeholder*="2fa" i]') ||
      document.querySelector('input[placeholder*="mã" i]')
    );
  }

  function findSubmitButton() {
    return (
      document.querySelector('button[type="submit"]') ||
      document.querySelector('input[type="submit"]') ||
      document.querySelector("form button.btn") ||
      document.querySelector("button.bg-primary") ||
      document.querySelector('button[class*="primary"]') ||
      document.querySelector('button[class*="login"]') ||
      document.querySelector('button[class*="sign"]') ||
      Array.from(document.querySelectorAll("form button, form input[type='button']")).find(
        (btn) => /sign\s*in|log\s*in|đăng\s*nhập|login/i.test(btn.textContent || btn.value || "")
      ) ||
      document.querySelector("form button")
    );
  }

  function waitFor(selectorFn, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const el = selectorFn();
      if (el) return resolve(el);

      const observer = new MutationObserver(() => {
        const found = selectorFn();
        if (found) {
          observer.disconnect();
          resolve(found);
        }
      });

      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
      });

      setTimeout(() => {
        observer.disconnect();
        reject(new Error("Timeout waiting for element"));
      }, timeout);
    });
  }

  async function autoLogin() {
    if (alreadyRan) return;
    alreadyRan = true;

    try {
      const data = await chrome.storage.local.get([
        "luoi_email",
        "luoi_password",
        "luoi_otp",
        "luoi_autoSubmit",
      ]);

      if (!data.luoi_email || !data.luoi_password) {
        console.log("[Lười] Chưa có email/password. Mở popup Noo để nhập.");
        alreadyRan = false;
        return;
      }

      console.log("[Lười] Đang tự động điền thông tin đăng nhập...");

      const emailInput = await waitFor(findEmailInput, 12000);
      const passwordInput = await waitFor(findPasswordInput, 5000);

      emailInput.focus();
      setNativeValue(emailInput, data.luoi_email);

      passwordInput.focus();
      setNativeValue(passwordInput, data.luoi_password);

      if (data.luoi_otp) {
        try {
          const otpInput = await waitFor(findOtpInput, 2500);
          setNativeValue(otpInput, data.luoi_otp);
        } catch (e) {
          // OTP không bắt buộc
        }
      }

      console.log("[Lười] ✓ Đã điền email + mật khẩu");

      if (data.luoi_autoSubmit !== false) {
        setTimeout(() => {
          const btn = findSubmitButton();
          if (btn) {
            btn.click();
            console.log("[Lười] ✓ Đã tự động bấm Sign In");
          } else {
            const form = document.querySelector("form");
            if (form) {
              form.submit();
              console.log("[Lười] ✓ Đã submit form");
            } else {
              console.log("[Lười] Không tìm thấy nút Sign In");
            }
          }
        }, 500);
      }
    } catch (err) {
      console.error("[Lười] Lỗi:", err.message);
      alreadyRan = false;
    }
  }

  function start() {
    autoLogin();
    setTimeout(autoLogin, 1500);
    setTimeout(autoLogin, 3000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }

  // Theo dõi SPA navigation
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (/login/i.test(location.pathname)) {
        alreadyRan = false;
        setTimeout(autoLogin, 800);
      }
    }
  }).observe(document, { subtree: true, childList: true });
})();

(function() {
  if (window.__nooFloatBtnInit) return;
  window.__nooFloatBtnInit = true;
  var floatBtn = null;
  var DEFAULT_SIZE = 40;
  function applySize(sz) {
    if (!floatBtn) return;
    var s = Math.max(20, Math.min(64, Number(sz) || DEFAULT_SIZE));
    floatBtn.style.width = s + "px";
    floatBtn.style.height = s + "px";
  }
  function createBtn(size) {
    if (floatBtn) return;
    floatBtn = document.createElement("button");
    floatBtn.id = "__noo_float_trash_btn";
    floatBtn.title = "Noo Cleaner – Clear History";
    floatBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6M14 11v6"></path><path d="M9 6V4h6v2"></path></svg>';
    floatBtn.addEventListener("click", function() {
      floatBtn.style.transform = "scale(0.5)";
      setTimeout(function() {
        floatBtn.style.transform = "";
      }, 350);
      chrome.runtime.sendMessage({
        action: "clearBtn"
      });
    });
    document.body.appendChild(floatBtn);
    applySize(size);
  }
  function removeBtn() {
    if (floatBtn) {
      floatBtn.remove();
      floatBtn = null;
    }
  }
  function checkAndApply(isEnabled, size) {
    if (isEnabled) {
      createBtn(size);
      applySize(size);
    } else {
      removeBtn();
    }
  }
  chrome.storage.local.get([ "floatbtn", "floatbtnSize" ], function(data) {
    checkAndApply(!!data.floatbtn, data.floatbtnSize || DEFAULT_SIZE);
  });
  chrome.storage.onChanged.addListener(function(changes) {
    var needsCheck = changes.floatbtn !== undefined || changes.floatbtnSize !== undefined;
    if (!needsCheck) return;
    chrome.storage.local.get([ "floatbtn", "floatbtnSize" ], function(data) {
      checkAndApply(!!data.floatbtn, data.floatbtnSize || DEFAULT_SIZE);
    });
  });
})();

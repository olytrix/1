chrome.runtime.onInstalled.addListener(initializeDefaults);

chrome.runtime.onStartup.addListener(initializeDefaults);

initializeDefaults();

function initializeDefaults() {
  chrome.storage.local.get([ "fixTab", "fakeRef", "lensPC", "lensPE", "uiFixer", "autoCaptcha", "timePeriod", "clearHistoryEnabled", "floatbtn", "clearHistoryUrls", "autoCloseOnUrlMatch", "limitList", "limitInputMode" ], res => {
    const defaults = {};
    if (res.fixTab === undefined) defaults.fixTab = false;
    if (res.fakeRef === undefined) defaults.fakeRef = false;
    if (res.lensPC === undefined) defaults.lensPC = false;
    if (res.lensPE === undefined) defaults.lensPE = false;
    if (res.uiFixer === undefined) defaults.uiFixer = false;
    if (res.autoCaptcha === undefined) defaults.autoCaptcha = false;
    if (res.timePeriod === undefined) defaults.timePeriod = "last_hour";
    if (res.clearHistoryEnabled === undefined) defaults.clearHistoryEnabled = false;
    if (res.floatbtn === undefined) defaults.floatbtn = false;
    if (res.clearHistoryUrls === undefined) defaults.clearHistoryUrls = [];
    if (res.autoCloseOnUrlMatch === undefined) defaults.autoCloseOnUrlMatch = false;
    if (res.limitList === undefined) defaults.limitList = [];
    if (res.limitInputMode === undefined) defaults.limitInputMode = "link";
    if (Object.keys(defaults).length) chrome.storage.local.set(defaults);
    updateScripts(!!res.fixTab, !!res.fakeRef, !!res.lensPC, !!res.lensPE, !!res.uiFixer, !!res.autoCaptcha);
  });
}

const SCRIPT_TOGGLE_KEYS = [ "fixTab", "fakeRef", "lensPC", "lensPE", "uiFixer", "autoCaptcha" ];

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace !== "local") return;
  if (!SCRIPT_TOGGLE_KEYS.some(k => k in changes)) return;
  chrome.storage.local.get(SCRIPT_TOGGLE_KEYS, res => {
    updateScripts(!!res.fixTab, !!res.fakeRef, !!res.lensPC, !!res.lensPE, !!res.uiFixer, !!res.autoCaptcha);
  });
});

function getTimeInterval(period) {
  switch (period) {
   case "last_hour":
    return (new Date).getTime() - 36e5;

   case "last_day":
    return (new Date).getTime() - 864e5;

   case "last_week":
    return (new Date).getTime() - 6048e5;

   case "last_month":
    return (new Date).getTime() - 24192e5;

   default:
    return 0;
  }
}

const ALL_DATA = {
  appcache: true,
  cache: true,
  cacheStorage: true,
  cookies: true,
  downloads: true,
  fileSystems: true,
  formData: true,
  history: true,
  indexedDB: true,
  localStorage: true,
  passwords: true,
  pluginData: true,
  serviceWorkers: true,
  webSQL: true
};

function clearHistory(tab, timePeriod) {
  chrome.storage.local.get([ "timePeriod" ], data => {
    const selected = timePeriod || data.timePeriod || "last_hour";
    const since = getTimeInterval(selected);
    chrome.browsingData.remove({
      since: since
    }, ALL_DATA);
  });
}

function normalizeTriggers(triggers) {
  if (!Array.isArray(triggers)) return [];
  return triggers.map(item => {
    if (typeof item === "string") return {
      url: item,
      mode: "contains"
    };
    if (item && typeof item.url === "string") {
      return {
        url: item.url,
        mode: item.mode === "exact" ? "exact" : "contains"
      };
    }
    return null;
  }).filter(Boolean);
}

function urlMatchesAnyTrigger(url, triggers) {
  if (!url) return null;
  const list = normalizeTriggers(triggers);
  const found = list.find(t => {
    if (!t.url) return false;
    return t.mode === "exact" ? url === t.url : url.includes(t.url);
  });
  return found ? found.url : null;
}

chrome.webNavigation.onBeforeNavigate.addListener(details => {
  if (details.frameId !== 0) return;
  chrome.storage.local.get([ "clearHistoryEnabled", "clearHistoryUrls", "autoCloseOnUrlMatch", "autoCloseDelaySeconds", "timePeriod" ], res => {
    if (!res.clearHistoryEnabled) return;
    const matched = urlMatchesAnyTrigger(details.url, res.clearHistoryUrls);
    if (!matched) return;
    clearHistory(null, res.timePeriod || "last_hour");
    logActivity(`Clear History : Tự động xoá vì khớp URL "${matched}" (${details.url})`);
    if (res.autoCloseOnUrlMatch) {
      const tabId = details.tabId;
      const delaySec = Math.max(0, Number(res.autoCloseDelaySeconds) || 0);
      const closeTab = () => {
        chrome.tabs.remove(tabId, () => {
          if (chrome.runtime.lastError) {}
        });
        logActivity(`Tự đóng tab vì khớp URL "${matched}" (${details.url})` + (delaySec > 0 ? ` — đã chờ ${delaySec} giây` : ""));
      };
      if (delaySec > 0) {
        setTimeout(closeTab, delaySec * 1e3);
      } else {
        closeTab();
      }
    }
  });
});

const RELOAD_ALARM = "noo_reload_active_tab";

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== RELOAD_ALARM) return;
  chrome.tabs.query({
    active: true,
    currentWindow: true
  }, tabs => {
    const tab = tabs && tabs[0];
    if (tab && tab.id) chrome.tabs.reload(tab.id);
  });
});

function logActivity() {}

const attachedTabs = new Set;

function ensureAttached(tabId, force) {
  return new Promise(resolve => {
    if (!force && attachedTabs.has(tabId)) return resolve(true);
    chrome.debugger.attach({
      tabId: tabId
    }, "1.3", () => {
      const err = chrome.runtime.lastError;
      if (err) {
        if (/already attach/i.test(err.message || "")) {
          attachedTabs.add(tabId);
          resolve(true);
          return;
        }
        console.warn("[AutoClick] Không thể attach debugger:", err.message);
        attachedTabs.delete(tabId);
        resolve(false);
        return;
      }
      attachedTabs.add(tabId);
      resolve(true);
    });
  });
}

function sendMouseEvent(tabId, type, x, y) {
  return new Promise(resolve => {
    chrome.debugger.sendCommand({
      tabId: tabId
    }, "Input.dispatchMouseEvent", {
      type: type,
      x: x,
      y: y,
      button: "left",
      clickCount: 1,
      buttons: type === "mousePressed" ? 1 : 0
    }, () => resolve(!chrome.runtime.lastError));
  });
}

async function ensureAndSend(tabId, sendFn, ...args) {
  let ok = await ensureAttached(tabId, false);
  if (ok) {
    const sent = await sendFn(tabId, ...args);
    if (sent) return true;
    attachedTabs.delete(tabId);
  }
  ok = await ensureAttached(tabId, true);
  if (!ok) return false;
  return sendFn(tabId, ...args);
}

chrome.debugger.onDetach.addListener(source => {
  if (source.tabId) {
    attachedTabs.delete(source.tabId);
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  attachedTabs.delete(tabId);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResp) => {
  if (msg.type === "AC_TEST_CLICK") {
    const tabId = msg.tabId;
    if (typeof tabId !== "number") {
      sendResp({
        ok: false
      });
      return false;
    }
    (async () => {
      const okPress = await ensureAndSend(tabId, sendMouseEvent, "mousePressed", msg.x, msg.y);
      const okRelease = okPress ? await ensureAndSend(tabId, sendMouseEvent, "mouseReleased", msg.x, msg.y) : false;
      sendResp({
        ok: okPress && okRelease
      });
    })();
    return true;
  }
  if (msg.type === "AC_MOUSE_PRESS" || msg.type === "AC_MOUSE_RELEASE") {
    if (!sender.tab || sender.tab.id === undefined) {
      sendResp({
        ok: false
      });
      return false;
    }
    const tabId = sender.tab.id;
    (async () => {
      const cdpType = msg.type === "AC_MOUSE_PRESS" ? "mousePressed" : "mouseReleased";
      const success = await ensureAndSend(tabId, sendMouseEvent, cdpType, msg.x, msg.y);
      if (!success) {
        logActivity(`Auto Click mất kết nối — bấm hụt tại toạ độ (${Math.round(msg.x)}, ${Math.round(msg.y)})`, {
          x: msg.x,
          y: msg.y,
          tabId: tabId,
          kind: "disconnect"
        });
      }
      sendResp({
        ok: success
      });
    })();
    return true;
  }
  if (msg.action === "scheduleReload") {
    chrome.alarms.clear(RELOAD_ALARM, () => {
      chrome.alarms.create(RELOAD_ALARM, {
        delayInMinutes: 2 / 60
      });
    });
    return false;
  }
  if (msg.action === "clearHistory") {
    clearHistory(msg.tab, msg.timePeriod);
    return false;
  }
  if (msg.action === "clearBtn") {
    chrome.storage.local.get([ "timePeriod" ], data => {
      clearHistory(null, data.timePeriod || "last_hour");
    });
    return false;
  }
  if (msg.action === "openLhRedirectTab") {
    if (msg.url) chrome.tabs.create({
      url: msg.url,
      active: true
    });
    return false;
  }
  if (msg.type === "RERUN_ACTIVE_TAB") {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, tabs => {
      if (tabs[0]) {
        msInjectScripts(tabs[0].id, tabs[0].url, "document-start");
        msInjectScripts(tabs[0].id, tabs[0].url, "document-end");
        msInjectScripts(tabs[0].id, tabs[0].url, "document-idle");
      }
    });
    return false;
  }
  if (msg.type === "RELOAD_MATCHING_TABS") {
    const patterns = msg.matches || [];
    const originTabId = Number(msg.originTabId) || null;
    if (originTabId) {
      chrome.tabs.get(originTabId, tab => {
        if (chrome.runtime.lastError || !tab) return;
        if (tab.url && msUrlMatches(tab.url, patterns)) {
          chrome.tabs.reload(tab.id);
        }
      });
      return false;
    }
    chrome.tabs.query({
      active: true,
      lastFocusedWindow: true
    }, tabs => {
      const tab = tabs && tabs[0];
      if (tab && tab.url && msUrlMatches(tab.url, patterns)) {
        chrome.tabs.reload(tab.id);
      }
    });
    return false;
  }
  if (msg.type === "GM_XHR") {
    const payload = msg.payload || {};
    (async () => {
      try {
        const init = {
          method: payload.method || "GET",
          headers: payload.headers || {}
        };
        if (payload.data !== undefined && payload.data !== null && init.method !== "GET" && init.method !== "HEAD") {
          init.body = payload.data;
        }
        const res = await fetch(payload.url, init);
        const text = await res.text();
        let responseHeaders = "";
        res.headers.forEach((v, k) => {
          responseHeaders += `${k}: ${v}\r\n`;
        });
        sendResp({
          responseText: text,
          status: res.status,
          statusText: res.statusText,
          responseHeaders: responseHeaders,
          finalUrl: res.url
        });
      } catch (err) {
        sendResp({
          error: err && err.message ? err.message : String(err)
        });
      }
    })();
    return true;
  }
  return false;
});

function msPatternToRegex(pattern) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
  return new RegExp("^" + escaped + "$");
}

function msUrlMatches(url, matches) {
  if (!matches || matches.length === 0) return false;
  return matches.some(pattern => {
    try {
      return msPatternToRegex(pattern.trim()).test(url);
    } catch (e) {
      return false;
    }
  });
}

async function msGetScripts() {
  const {scripts: scripts = []} = await chrome.storage.local.get("scripts");
  return scripts;
}

function msRunInPage(code, name, grants) {
  try {
    if (Array.isArray(grants) && grants.includes("GM_xmlhttpRequest") && !window.__nooGmXhrReady) {
      window.__nooGmXhrReady = true;
      const pending = {};
      let counter = 0;
      window.addEventListener("message", event => {
        if (event.source !== window) return;
        const data = event.data;
        if (!data || data.__nooGmXhrResponse !== true) return;
        const cb = pending[data.id];
        if (!cb) return;
        delete pending[data.id];
        cb(data);
      });
      window.GM_xmlhttpRequest = function(details) {
        details = details || {};
        const id = "gmxhr_" + ++counter + "_" + Math.random().toString(36).slice(2);
        pending[id] = function(resp) {
          if (resp.error) {
            if (typeof details.onerror === "function") details.onerror({
              error: resp.error
            });
            return;
          }
          if (typeof details.onload === "function") {
            details.onload({
              responseText: resp.responseText,
              response: resp.responseText,
              status: resp.status,
              statusText: resp.statusText,
              readyState: 4,
              responseHeaders: resp.responseHeaders,
              finalUrl: resp.finalUrl
            });
          }
        };
        window.postMessage({
          __nooGmXhrRequest: true,
          id: id,
          url: details.url,
          method: details.method || "GET",
          headers: details.headers || {},
          data: details.data
        }, "*");
        return {
          abort() {}
        };
      };
      window.GM = window.GM || {};
      window.GM.xmlHttpRequest = window.GM_xmlhttpRequest;
    }
    new Function(code)();
  } catch (err) {
    console.error(`[MyScripts] Lỗi khi chạy script "${name}":`, err);
  }
}

async function msInjectScripts(tabId, url, runAtFilter) {
  if (!url || !/^https?:/.test(url)) return;
  const scripts = await msGetScripts();
  const toRun = scripts.filter(s => s.enabled && (s.runAt || "document-idle") === runAtFilter && msUrlMatches(url, s.matches));
  for (const script of toRun) {
    try {
      await chrome.scripting.executeScript({
        target: {
          tabId: tabId
        },
        world: "MAIN",
        injectImmediately: runAtFilter !== "document-idle",
        func: msRunInPage,
        args: [ script.code, script.name, script.grant || [] ]
      });
    } catch (err) {
      console.error("[MyScripts] Không thể tiêm script:", script.name, err);
    }
  }
}

chrome.webNavigation.onCommitted.addListener(details => {
  if (details.frameId !== 0) return;
  msInjectScripts(details.tabId, details.url, "document-start");
});

chrome.webNavigation.onDOMContentLoaded.addListener(details => {
  if (details.frameId !== 0) return;
  msInjectScripts(details.tabId, details.url, "document-end");
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url) {
    msInjectScripts(tabId, tab.url, "document-idle");
  }
});

let updateScriptsQueue = Promise.resolve();

function updateScripts(fixTab, fakeRef, lensPC, lensPE, uiFixer, autoCaptcha) {
  updateScriptsQueue = updateScriptsQueue.catch(() => {}).then(() => runUpdateScripts(fixTab, fakeRef, lensPC, lensPE, uiFixer, autoCaptcha));
  return updateScriptsQueue;
}

async function runUpdateScripts(fixTab, fakeRef, lensPC, lensPE, uiFixer, autoCaptcha) {
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts();
    if (existing.length) {
      await chrome.scripting.unregisterContentScripts({
        ids: existing.map(s => s.id)
      });
    }
    const scripts = [];
    if (fixTab) {
      scripts.push({
        id: "script_fixtab",
        matches: [ "<all_urls>" ],
        js: [ "script_fixtab.js" ],
        runAt: "document_start",
        world: "MAIN"
      });
    }
    if (fakeRef) {
      scripts.push({
        id: "script_referrer",
        matches: [ "<all_urls>" ],
        js: [ "script_referrer.js" ],
        runAt: "document_start",
        world: "MAIN"
      });
    }
    if (lensPC) {
      scripts.push({
        id: "script_lens_pc",
        matches: [ "<all_urls>" ],
        js: [ "script_lens_pc.js" ],
        runAt: "document_end"
      });
    }
    if (lensPE) {
      scripts.push({
        id: "script_lens_pe",
        matches: [ "<all_urls>" ],
        js: [ "script_lens_pe.js" ],
        runAt: "document_end"
      });
    }
    if (uiFixer) {
      scripts.push({
        id: "script_uifixer",
        matches: [ "<all_urls>" ],
        js: [ "script_uifixer.js" ],
        runAt: "document_start",
        allFrames: true
      });
    }
    if (autoCaptcha) {
      scripts.push({
        id: "script_autocaptcha",
        matches: [ "<all_urls>" ],
        js: [ "script_autocaptcha.js" ],
        runAt: "document_start",
        world: "MAIN",
        allFrames: true
      });
    }
    if (scripts.length) await chrome.scripting.registerContentScripts(scripts);
  } catch (e) {
    console.error(e);
  }
}

// ========== AUTO SYNC FIND LINK TỪ GITHUB REPO ==========
const LH_MAP_KEY = "lhRedirectMap";
const LH_REPO_URL_KEY = "lhRedirectRepoUrl";
const LH_SYNC_ALARM = "noo_lh_repo_sync";
const LH_SYNC_INTERVAL_MIN = 15; // mỗi 15 phút tự tải lại

function normalizeLinkBg(link) {
  let finalLink = (link || "").trim();
  if (!finalLink) return "";
  if (!/^https?:\/\//i.test(finalLink)) finalLink = "https://" + finalLink;
  return finalLink;
}

function parseBulkTextBg(text) {
  const pairs = [];
  const lines = (text || "").split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    let numsPart = "", linkPart = "";
    const multiSep = line.match(/^([\d,\s]+)\s*[|：:]\s*(.+)$/);
    const multiSpace = line.match(/^([\d,\s]+)\s+(https?:\/\/\S+|\S+\.\S+.*)$/i);
    if (multiSep) {
      numsPart = multiSep[1];
      linkPart = multiSep[2].trim();
    } else if (multiSpace) {
      numsPart = multiSpace[1];
      linkPart = multiSpace[2].trim();
    } else continue;
    const finalLink = normalizeLinkBg(linkPart);
    if (!finalLink) continue;
    const nums = numsPart.split(/[,\s]+/).map(s => s.trim()).filter(s => /^\d+$/.test(s));
    for (const num of nums) pairs.push({ num, link: finalLink });
  }
  return pairs;
}

function parseRepoContentBg(text) {
  const trimmed = (text || "").trim();
  if (!trimmed) return [];
  try {
    const obj = JSON.parse(trimmed);
    if (obj && typeof obj === "object" && !Array.isArray(obj)) {
      const pairs = [];
      for (const [key, value] of Object.entries(obj)) {
        if (/^\d+$/.test(String(key)) && value) {
          pairs.push({ num: String(key), link: normalizeLinkBg(String(value)) });
        }
      }
      if (pairs.length > 0) return pairs;
    }
  } catch (e) {}
  return parseBulkTextBg(trimmed);
}

async function syncLhRedirectFromRepo(force) {
  try {
    const res = await chrome.storage.local.get([LH_REPO_URL_KEY]);
    const url = (res[LH_REPO_URL_KEY] || "").trim();
    if (!url) return { ok: false, reason: "no_url" };

    let parsed;
    try {
      parsed = new URL(url);
      if (!/^https?:$/i.test(parsed.protocol)) throw new Error("bad protocol");
    } catch (e) {
      return { ok: false, reason: "bad_url" };
    }

    const resp = await fetch(parsed.toString(), {
      method: "GET",
      cache: "no-store",
      credentials: "omit"
    });
    if (!resp.ok) return { ok: false, reason: `http_${resp.status}` };

    const text = await resp.text();
    const pairs = parseRepoContentBg(text);
    if (pairs.length === 0) return { ok: false, reason: "empty" };

    const newMap = {};
    for (const { num, link } of pairs) {
      if (num && link) newMap[num] = link;
    }
    await chrome.storage.local.set({ [LH_MAP_KEY]: newMap });
    console.log(`[Noo] Find Link: đã đồng bộ ${Object.keys(newMap).length} cặp từ repo`);
    return { ok: true, count: Object.keys(newMap).length };
  } catch (err) {
    console.warn("[Noo] Find Link sync lỗi:", err.message);
    return { ok: false, reason: err.message };
  }
}

function scheduleLhSync() {
  chrome.alarms.clear(LH_SYNC_ALARM, () => {
    chrome.alarms.create(LH_SYNC_ALARM, {
      delayInMinutes: 0.5,          // chạy lần đầu sau 30s
      periodInMinutes: LH_SYNC_INTERVAL_MIN
    });
  });
}

// Gọi khi cài / khởi động
chrome.runtime.onInstalled.addListener(() => {
  scheduleLhSync();
  setTimeout(() => syncLhRedirectFromRepo(), 3000);
});
chrome.runtime.onStartup.addListener(() => {
  scheduleLhSync();
  setTimeout(() => syncLhRedirectFromRepo(), 3000);
});

// Alarm handler (gộp với cái cũ)
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === LH_SYNC_ALARM) {
    syncLhRedirectFromRepo();
  }
});

// Khi user đổi repo URL → sync ngay
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace !== "local") return;
  if (LH_REPO_URL_KEY in changes) {
    const newUrl = changes[LH_REPO_URL_KEY].newValue;
    if (newUrl) {
      scheduleLhSync();
      setTimeout(() => syncLhRedirectFromRepo(true), 500);
    }
  }
});

// Cho phép UI force sync
chrome.runtime.onMessage.addListener((msg, sender, sendResp) => {
  if (msg && msg.action === "syncLhRepoNow") {
    syncLhRedirectFromRepo(true).then(result => {
      try { sendResp(result); } catch (e) {}
    });
    return true; // async
  }
});

// Khởi tạo alarm ngay khi service worker load
scheduleLhSync();
setTimeout(() => syncLhRedirectFromRepo(), 2000);

// ==================== Limit List (từ Shizuka) ====================
// limitList = mảng mã nhiệm vụ dạng "số-số" (vd: 236-2)
// Cơ chế đúng (Shizuka):
//   - Khi vào URL path /CODE/... mà CODE nằm trong limitList
//     → BỎ QUA automation (ở Noo: bỏ qua lhRedirect)
//   - Không đóng tab, không chặn truy cập
// Logic chặn redirect nằm trong script_lhredirect.js


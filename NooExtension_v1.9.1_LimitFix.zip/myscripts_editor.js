function uid() {
  return "scr_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

async function getScripts() {
  const {scripts: scripts = []} = await chrome.storage.local.get("scripts");
  return scripts;
}

async function saveScripts(scripts) {
  await chrome.storage.local.set({
    scripts: scripts
  });
}

const params = new URLSearchParams(location.search);

const editingId = params.get("id");

const originTabId = params.get("originTabId");

function logActivity() {}

const nameEl = document.getElementById("name");

const matchesEl = document.getElementById("matches");

const codeEl = document.getElementById("code");

let currentEnabled = true;

const titleEl = document.getElementById("title");

const statusEl = document.getElementById("status");

const gutterEl = document.getElementById("codeGutter");

const codeErrorEl = document.getElementById("codeError");

const codeOkEl = document.getElementById("codeOk");

const sandboxFrame = document.getElementById("sandboxFrame");

let reqId = 0;

const pendingChecks = new Map;

window.addEventListener("message", event => {
  if (event.source !== sandboxFrame.contentWindow) return;
  const {id: id} = event.data || {};
  const resolve = pendingChecks.get(id);
  if (resolve) {
    pendingChecks.delete(id);
    resolve(event.data);
  }
});

function checkSyntaxInSandbox(code) {
  return new Promise(resolve => {
    const id = ++reqId;
    pendingChecks.set(id, resolve);
    sandboxFrame.contentWindow.postMessage({
      id: id,
      code: code
    }, "*");
  });
}

function updateGutter(errorLine) {
  const lineCount = codeEl.value.split("\n").length;
  const lines = [];
  for (let i = 1; i <= lineCount; i++) {
    lines.push(i === errorLine ? `<span class="line error-line">${i}</span>` : `<span class="line">${i}</span>`);
  }
  gutterEl.innerHTML = lines.join("\n");
}

codeEl.addEventListener("scroll", () => {
  gutterEl.scrollTop = codeEl.scrollTop;
});

codeEl.addEventListener("keydown", e => {
  if (e.key === "Tab") {
    e.preventDefault();
    const start = codeEl.selectionStart;
    const end = codeEl.selectionEnd;
    codeEl.value = codeEl.value.slice(0, start) + "  " + codeEl.value.slice(end);
    codeEl.selectionStart = codeEl.selectionEnd = start + 2;
    checkSyntax();
  }
});

let syntaxTimer = null;

function checkSyntax() {
  updateGutter();
  clearTimeout(syntaxTimer);
  syntaxTimer = setTimeout(() => {
    const code = codeEl.value;
    if (!code.trim()) {
      codeErrorEl.style.display = "none";
      codeOkEl.style.display = "none";
      updateGutter();
      return;
    }
    checkSyntaxInSandbox(code).then(result => {
      if (result.ok) {
        codeErrorEl.style.display = "none";
        codeOkEl.style.display = "block";
        updateGutter();
      } else {
        codeOkEl.style.display = "none";
        codeErrorEl.style.display = "block";
        codeErrorEl.textContent = result.line ? `⚠ Lỗi cú pháp ở dòng ${result.line}: ${result.message}` : `⚠ Lỗi cú pháp: ${result.message}`;
        updateGutter(result.line);
      }
    });
  }, 300);
}

codeEl.addEventListener("input", checkSyntax);

function parseUserScriptHeader(code) {
  const block = code.match(/\/\/\s*==UserScript==([\s\S]*?)\/\/\s*==\/UserScript==/);
  if (!block) return null;
  let name = "";
  let runAt = "";
  const matches = [];
  const grants = [];
  const lines = block[1].split("\n");
  for (const line of lines) {
    const m = line.match(/^\s*\/\/\s*@(\S+)\s+(.*?)\s*$/);
    if (!m) continue;
    const key = m[1].toLowerCase();
    const value = m[2].trim();
    if (!value) continue;
    if (key === "name" && !name) name = value;
    if (key === "match" || key === "include") matches.push(value);
    if (key === "run-at" && !runAt) runAt = value;
    if (key === "grant") grants.push(value);
  }
  return {
    name: name,
    matches: matches,
    runAt: runAt,
    grants: grants
  };
}

let parsedRunAt = "document-idle";

let parsedGrants = [ "none" ];

const RUN_AT_MAP = {
  "document-start": "document_start",
  "document-end": "document_end",
  "document-idle": "document_idle",
  "document-body": "document_start"
};

function stripNamespaceLine(code) {
  return code.replace(/^[ \t]*\/\/[ \t]*@(namespace|description|version)\b.*\r?\n?/gim, "");
}

function autofillFromHeader() {
  const parsed = parseUserScriptHeader(codeEl.value);
  if (!parsed || !parsed.name && parsed.matches.length === 0) return;
  if (parsed.name) nameEl.value = parsed.name;
  if (parsed.matches.length > 0) matchesEl.value = parsed.matches.join("\n");
  parsedRunAt = RUN_AT_MAP[(parsed.runAt || "").toLowerCase()] ? parsed.runAt.toLowerCase() : "document-idle";
  parsedGrants = parsed.grants.length > 0 ? parsed.grants : [ "none" ];
}

codeEl.addEventListener("input", autofillFromHeader);

const allSitesEl = document.getElementById("allSites");

let savedMatchesBeforeAllSites = "";

function applyAllSitesState() {
  if (allSitesEl.checked) {
    savedMatchesBeforeAllSites = matchesEl.value;
    matchesEl.value = "*://*/*";
    matchesEl.disabled = true;
  } else {
    matchesEl.disabled = false;
    matchesEl.value = savedMatchesBeforeAllSites;
  }
}

allSitesEl.addEventListener("change", applyAllSitesState);

const scriptUrlEl = document.getElementById("scriptUrl");

const loadUrlBtn = document.getElementById("loadUrlBtn");

const urlStatusEl = document.getElementById("urlStatus");

loadUrlBtn.addEventListener("click", async () => {
  const url = scriptUrlEl.value.trim();
  urlStatusEl.className = "hint";
  if (!url) {
    urlStatusEl.textContent = "Vui lòng dán URL trước.";
    urlStatusEl.className = "hint error";
    return;
  }
  let parsed;
  try {
    parsed = new URL(url);
    if (!/^https?:$/.test(parsed.protocol)) throw new Error("protocol");
  } catch (e) {
    urlStatusEl.textContent = "URL không hợp lệ (chỉ hỗ trợ http/https).";
    urlStatusEl.className = "hint error";
    return;
  }
  loadUrlBtn.disabled = true;
  urlStatusEl.textContent = "Đang tải...";
  try {
    const res = await fetch(parsed.toString(), {
      cache: "no-store"
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    if (!text.trim()) throw new Error("Nội dung rỗng");
    codeEl.value = stripNamespaceLine(text);
    checkSyntax();
    autofillFromHeader();
    urlStatusEl.textContent = `Đã tải ${text.length.toLocaleString("vi-VN")} ký tự. Hãy đọc lại code trước khi lưu.`;
    urlStatusEl.className = "hint success";
  } catch (err) {
    urlStatusEl.textContent = `Không tải được: ${err.message}`;
    urlStatusEl.className = "hint error";
  } finally {
    loadUrlBtn.disabled = false;
  }
});

(async () => {
  if (editingId) {
    const scripts = await getScripts();
    const s = scripts.find(x => x.id === editingId);
    if (s) {
      titleEl.textContent = "Sửa script";
      nameEl.value = s.name;
      matchesEl.value = (s.matches || []).join("\n");
      codeEl.value = s.code;
      currentEnabled = s.enabled;
      parsedRunAt = s.runAt || "document-idle";
      parsedGrants = s.grant || [ "none" ];
      const savedMatches = s.matches || [];
      if (savedMatches.length === 1 && savedMatches[0] === "*://*/*") {
        allSitesEl.checked = true;
        matchesEl.disabled = true;
      }
    }
  }
  checkSyntax();
  autofillFromHeader();
})();

document.getElementById("saveBtn").addEventListener("click", async () => {
  const name = nameEl.value.trim();
  const matches = matchesEl.value.split("\n").map(m => m.trim()).filter(Boolean);
  const code = codeEl.value;
  if (!name) {
    statusEl.textContent = "Vui lòng nhập tên script.";
    return;
  }
  if (matches.length === 0) {
    statusEl.textContent = "Vui lòng nhập ít nhất 1 URL pattern.";
    return;
  }
  const scripts = await getScripts();
  let isNew = false;
  if (editingId) {
    const s = scripts.find(x => x.id === editingId);
    if (s) {
      s.name = name;
      s.matches = matches;
      s.code = code;
      s.enabled = currentEnabled;
      s.runAt = parsedRunAt;
      s.grant = parsedGrants;
    }
  } else {
    isNew = true;
    scripts.push({
      id: uid(),
      name: name,
      matches: matches,
      code: code,
      enabled: currentEnabled,
      runAt: parsedRunAt,
      grant: parsedGrants
    });
  }
  await saveScripts(scripts);
  logActivity(`Userscript "${name}" : ${isNew ? "Đã thêm mới" : "Đã cập nhật"}`);
  chrome.runtime.sendMessage({
    type: "RELOAD_MATCHING_TABS",
    matches: matches,
    originTabId: originTabId
  });
  statusEl.textContent = "Đã lưu ✓";
  setTimeout(() => window.close(), 500);
});

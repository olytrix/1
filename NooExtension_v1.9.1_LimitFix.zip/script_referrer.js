(() => {
  "use strict";
  console.log("[Extension] Fake Referrer Activated");
  const fakeReferrer = "https://www.google.com/";
  const override = (obj, prop, value) => {
    try {
      Object.defineProperty(obj, prop, {
        get() {
          return value;
        },
        configurable: true,
        enumerable: true
      });
    } catch (e) {}
  };
  override(Document.prototype, "referrer", fakeReferrer);
  override(document, "referrer", fakeReferrer);
  try {
    const original = performance.getEntriesByType;
    performance.getEntriesByType = function(type) {
      const result = original.call(this, type);
      if (type === "navigation" && result && result.length > 0 && result[0]) {
        try {
          Object.defineProperty(result[0], "name", {
            get() {
              return fakeReferrer;
            },
            configurable: true
          });
        } catch (e) {}
      }
      return result;
    };
  } catch (e) {}
})();

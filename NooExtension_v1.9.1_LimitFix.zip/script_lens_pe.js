(() => {
  "use strict";
  function openLens(img) {
    const src = img.currentSrc || img.src;
    if (!src || src.startsWith("data:")) return;
    window.open("https://lens.google.com/uploadbyurl?url=" + encodeURIComponent(src), "_blank");
  }
  let tapCount = 0;
  let lastImg = null;
  let timer = null;
  document.addEventListener("touchend", e => {
    const img = e.target.closest("img");
    if (!img) return;
    if (img !== lastImg) {
      tapCount = 0;
      lastImg = img;
    }
    tapCount++;
    clearTimeout(timer);
    if (tapCount === 3) {
      tapCount = 0;
      openLens(img);
      return;
    }
    timer = setTimeout(() => {
      tapCount = 0;
    }, 600);
  }, true);
})();

(function() {
  const BC_STORAGE_KEY = "bcState";
  let peSignalInterval = null;
  let peSignalTimeout = null;
  let currentMode = "pc";
  function dispatchPeSignal(btn) {
    if (currentMode !== "pe") return;
    const rect = btn.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    window.dispatchEvent(new CustomEvent("__bc_uifixer_pe_signal__", {
      detail: {
        x: x,
        y: y
      }
    }));
  }
  function startPeSignal(btn) {
    if (currentMode !== "pe") return;
    dispatchPeSignal(btn);
    if (peSignalInterval) clearInterval(peSignalInterval);
    peSignalInterval = setInterval(() => {
      if (currentMode !== "pe" || !btn.isConnected) {
        clearInterval(peSignalInterval);
        peSignalInterval = null;
        return;
      }
      dispatchPeSignal(btn);
    }, 1e3);
  }
  function stopPeSignal() {
    if (peSignalTimeout) {
      clearTimeout(peSignalTimeout);
      peSignalTimeout = null;
    }
    if (peSignalInterval) {
      clearInterval(peSignalInterval);
      peSignalInterval = null;
    }
  }
  function applyFix(btn, deviceMode) {
    currentMode = deviceMode;
    btn.style.setProperty("position", "fixed", "important");
    btn.style.setProperty("top", "50%", "important");
    btn.style.setProperty("left", "50%", "important");
    btn.style.setProperty("transform", "translate(-50%,-50%)", "important");
    btn.style.setProperty("z-index", "2147483647", "important");
    const r = btn.getBoundingClientRect();
    if (r.top < 0 || r.bottom > window.innerHeight) {
      btn.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    }
    if (deviceMode === "pe") {
      btn.style.setProperty("outline", "3px solid red", "important");
      btn.style.setProperty("outline-offset", "3px", "important");
      stopPeSignal();
      peSignalTimeout = setTimeout(() => {
        peSignalTimeout = null;
        startPeSignal(btn);
      }, 80);
    } else {
      btn.style.removeProperty("outline");
      btn.style.removeProperty("outline-offset");
      stopPeSignal();
    }
  }
  let lastFixedBtn = null;
  function tryFix() {
    const btn = document.querySelector("svg-btn");
    if (!btn) return;
    if (btn === lastFixedBtn && btn.isConnected) return;
    lastFixedBtn = btn;
    if (chrome && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([ BC_STORAGE_KEY ], res => {
        const saved = res && res[BC_STORAGE_KEY] || {};
        applyFix(btn, saved.deviceMode || "pc");
      });
    } else {
      applyFix(btn, "pc");
    }
  }
  setInterval(tryFix, 300);
  if (chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const change = changes[BC_STORAGE_KEY];
      if (!change) return;
      const btn = document.querySelector("svg-btn");
      const newDeviceMode = change.newValue && change.newValue.deviceMode || "pc";
      if (btn && newDeviceMode !== currentMode) applyFix(btn, newDeviceMode);
    });
  }
})();

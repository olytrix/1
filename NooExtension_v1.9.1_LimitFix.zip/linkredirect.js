try {
  if (typeof chrome !== "undefined" && chrome.storage) chrome.storage.local.set({
    noo_last_page: "linkredirect.html"
  });
} catch (e) {}

document.addEventListener("DOMContentLoaded", () => {
  const STORAGE_KEY = "lhRedirectMap";
  const REPO_URL_KEY = "lhRedirectRepoUrl";

  const sunIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"></path></svg>`;
  const moonIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path></svg>`;
  const DELETE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6M14 11v6"></path><path d="M9 6V4h6v2"></path></svg>`;

  const themeToggle = document.getElementById("themeToggle");
  const homeBtn = document.getElementById("homeBtn");
  const numInput = document.getElementById("numInput");
  const linkInput = document.getElementById("linkInput");
  const bulkInput = document.getElementById("bulkInput");
  const addBtn = document.getElementById("addBtn");
  const clearAllBtn = document.getElementById("clearAllBtn");
  const listContainer = document.getElementById("listContainer");

  const repoUrlInput = document.getElementById("repoUrlInput");
  const loadRepoBtn = document.getElementById("loadRepoBtn");
  const autoLoadRepo = document.getElementById("autoLoadRepo");
  const repoStatus = document.getElementById("repoStatus");

  // Ẩn checkbox cũ nếu còn (không cần nữa — luôn auto)
  if (autoLoadRepo && autoLoadRepo.parentElement) {
    autoLoadRepo.parentElement.style.display = "none";
  }

  if (homeBtn) {
    homeBtn.addEventListener("click", () => {
      try {
        if (typeof chrome !== "undefined" && chrome.storage) {
          chrome.storage.local.set({ noo_last_page: "popup.html" }, () => {
            window.location.href = "popup.html";
          });
          return;
        }
      } catch (e) {}
      window.location.href = "popup.html";
    });
  }

  function updateThemeIcon(isLight) {
    if (themeToggle) themeToggle.innerHTML = isLight ? moonIcon : sunIcon;
  }

  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(["isLightMode"], res => {
      if (res && res.isLightMode) {
        document.body.classList.add("light-mode");
        updateThemeIcon(true);
      } else {
        updateThemeIcon(false);
      }
    });
  }

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      document.body.classList.toggle("light-mode");
      const isLightMode = document.body.classList.contains("light-mode");
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ isLightMode });
      }
      updateThemeIcon(isLightMode);
    });
  }

  if (typeof chrome === "undefined" || !chrome.storage) return;

  function logActivity() {}

  function getMap() {
    return new Promise(resolve => {
      chrome.storage.local.get([STORAGE_KEY], res => resolve(res && res[STORAGE_KEY] || {}));
    });
  }

  function saveMap(map) {
    return new Promise(resolve => {
      chrome.storage.local.set({ [STORAGE_KEY]: map }, resolve);
    });
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  async function render() {
    const map = await getMap();
    const entries = Object.entries(map);
    if (entries.length === 0) {
      listContainer.innerHTML = '<div class="empty-msg">Chưa có cặp nào</div>';
      return;
    }
    listContainer.innerHTML = entries.map(([num, link]) => `
      <div class="list-item" data-num="${escapeHtml(num)}">
        <span class="num">${escapeHtml(num)}</span>
        <span class="link">${escapeHtml(link)}</span>
        <button class="del-btn" data-num="${escapeHtml(num)}" title="Xóa">${DELETE_ICON}</button>
      </div>
    `).join("");
    listContainer.querySelectorAll(".del-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const map = await getMap();
        delete map[btn.dataset.num];
        await saveMap(map);
        logActivity(`Find Link : đã xoá cặp "${btn.dataset.num}"`);
        render();
      });
    });
  }

  function normalizeLink(link) {
    let finalLink = (link || "").trim();
    if (!finalLink) return "";
    if (!/^https?:\/\//i.test(finalLink)) finalLink = "https://" + finalLink;
    return finalLink;
  }

  function parseBulkText(text) {
    const pairs = [];
    const lines = (text || "").split(/\r?\n/);
    for (const raw of lines) {
      const line = raw.trim();
      if (!line) continue;
      let numsPart = "", linkPart = "";
      const multiSep = line.match(/^([\d,\s]+)\s*[|：:]\s*(.+)$/);
      const multiSpace = line.match(/^([\d,\s]+)\s+(https?:\/\/\S+|\S+\.\S+.*)$/i);
      if (multiSep) {
        numsPart = multiSep[1];
        linkPart = multiSep[2].trim();
      } else if (multiSpace) {
        numsPart = multiSpace[1];
        linkPart = multiSpace[2].trim();
      } else continue;
      const finalLink = normalizeLink(linkPart);
      if (!finalLink) continue;
      const nums = numsPart.split(/[,\s]+/).map(s => s.trim()).filter(s => /^\d+$/.test(s));
      for (const num of nums) pairs.push({ num, link: finalLink });
    }
    return pairs;
  }

  function setRepoStatus(msg, type) {
    if (!repoStatus) return;
    repoStatus.textContent = msg || "";
    repoStatus.className = "hint" + (type ? " " + type : "");
  }

  // Force sync qua background (để dùng chung logic)
  function forceSyncFromRepo() {
    const url = (repoUrlInput && repoUrlInput.value || "").trim();
    if (!url) {
      setRepoStatus("Vui lòng dán link raw GitHub trước.", "error");
      return;
    }
    chrome.storage.local.set({ [REPO_URL_KEY]: url }, () => {
      if (loadRepoBtn) loadRepoBtn.disabled = true;
      setRepoStatus("Đang tải từ repo (background)...", "");
      chrome.runtime.sendMessage({ action: "syncLhRepoNow" }, result => {
        if (loadRepoBtn) loadRepoBtn.disabled = false;
        if (chrome.runtime.lastError) {
          setRepoStatus("Lỗi: " + chrome.runtime.lastError.message, "error");
          return;
        }
        if (result && result.ok) {
          setRepoStatus(`Đã tải ${result.count} cặp từ repo. Extension sẽ tự cập nhật mỗi 15 phút.`, "success");
          render();
        } else {
          setRepoStatus("Không tải được: " + (result && result.reason || "unknown"), "error");
        }
      });
    });
  }

  // Load URL đã lưu
  chrome.storage.local.get([REPO_URL_KEY], res => {
    if (repoUrlInput && res[REPO_URL_KEY]) {
      repoUrlInput.value = res[REPO_URL_KEY];
      setRepoStatus("Đã có repo. Extension tự đồng bộ nền mỗi 15 phút.", "success");
    }
    render();
  });

  if (repoUrlInput) {
    repoUrlInput.addEventListener("change", () => {
      const url = repoUrlInput.value.trim();
      chrome.storage.local.set({ [REPO_URL_KEY]: url });
      if (url) setRepoStatus("Đã lưu. Đang đồng bộ...", "");
    });
    repoUrlInput.addEventListener("keydown", e => {
      if (e.key === "Enter") {
        e.preventDefault();
        forceSyncFromRepo();
      }
    });
  }

  if (loadRepoBtn) {
    loadRepoBtn.addEventListener("click", forceSyncFromRepo);
  }

  // Khi map thay đổi từ background → cập nhật list
  chrome.storage.onChanged.addListener((changes, ns) => {
    if (ns === "local" && STORAGE_KEY in changes) {
      render();
    }
  });

  async function addPair() {
    const bulkText = bulkInput ? bulkInput.value.trim() : "";
    if (bulkText) {
      const pairs = parseBulkText(bulkText);
      if (pairs.length === 0) {
        alert("Không tìm thấy cặp hợp lệ.\nHỗ trợ:\n220:https://example.com\n118,199,237:https://example.com\n1 https://example.com");
        return;
      }
      const map = await getMap();
      let added = 0;
      for (const { num, link } of pairs) {
        if (!link) continue;
        map[num] = link;
        added++;
      }
      if (added === 0) {
        alert("Không có cặp nào được thêm.");
        return;
      }
      await saveMap(map);
      bulkInput.value = "";
      bulkInput.focus();
      render();
      return;
    }

    const num = (numInput && numInput.value || "").trim();
    const link = (linkInput && linkInput.value || "").trim();
    if (!num || !link) {
      alert("Vui lòng nhập cả số và link (hoặc dán nhiều dòng vào ô phía trên).");
      return;
    }
    if (!/^\d+$/.test(num)) {
      alert("Số phải là chữ số.");
      return;
    }
    const finalLink = normalizeLink(link);
    const map = await getMap();
    map[num] = finalLink;
    await saveMap(map);
    if (numInput) numInput.value = "";
    if (linkInput) linkInput.value = "";
    if (bulkInput) bulkInput.focus();
    render();
  }

  async function clearAll() {
    await saveMap({});
    render();
  }

  addBtn.addEventListener("click", addPair);
  clearAllBtn.addEventListener("click", clearAll);

  if (numInput) {
    numInput.addEventListener("keydown", e => { if (e.key === "Enter") addPair(); });
  }
  if (linkInput) {
    linkInput.addEventListener("keydown", e => { if (e.key === "Enter") addPair(); });
  }
  if (bulkInput) {
    bulkInput.addEventListener("keydown", e => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        addPair();
      }
    });
  }
});

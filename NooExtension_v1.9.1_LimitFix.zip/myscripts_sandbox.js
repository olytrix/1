window.addEventListener("message", event => {
  const data = event.data || {};
  const {id: id, code: code} = data;
  if (typeof code !== "string" || typeof id === "undefined") return;
  const result = {
    id: id,
    ok: true,
    message: null,
    line: null
  };
  try {
    new Function(code);
  } catch (err) {
    result.ok = false;
    result.message = err.message;
    const match = /<anonymous>:(\d+):(\d+)/.exec(err.stack || "");
    result.line = match ? Number(match[1]) : null;
  }
  event.source.postMessage(result, "*");
});

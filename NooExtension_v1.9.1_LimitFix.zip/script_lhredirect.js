(function () {
  "use strict";
  const STORAGE_KEY = "lhRedirectMap";
  const DELAY_MS = 1000;
  let lastProcessedUrl = "";

  function checkAndRedirect() {
    const currentUrl = window.location.href;
    if (currentUrl === lastProcessedUrl) return;
    lastProcessedUrl = currentUrl;

    const match = window.location.pathname.match(/^\/(\d+)-/);
    if (!match) return;
    const num = match[1];

    chrome.storage.local.get([STORAGE_KEY], (res) => {
      const map = (res && res[STORAGE_KEY]) || {};
      if (!Object.prototype.hasOwnProperty.call(map, num)) return;
      const target = map[num];
      if (!target) return;

      setTimeout(() => {
        chrome.runtime.sendMessage({
          action: "openLhRedirectTab",
          url: target,
        });
      }, DELAY_MS);
    });
  }

  setTimeout(checkAndRedirect, 100);
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      checkAndRedirect();
    }
  }, 500);
})();

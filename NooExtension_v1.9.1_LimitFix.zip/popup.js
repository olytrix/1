(function() {
  const OTHER_PAGES = [ "linkredirect.html" ];
  function reveal() {
    document.body && document.body.classList.remove("noo-boot-hidden");
  }
  try {
    if (typeof chrome === "undefined" || !chrome.storage) {
      reveal();
      return;
    }
    chrome.storage.local.get([ "noo_last_page" ], res => {
      const last = res && res.noo_last_page;
      if (last && OTHER_PAGES.includes(last)) {
        window.location.replace(last);
        return;
      }
      chrome.storage.local.set({
        noo_last_page: "popup.html"
      });
      reveal();
    });
  } catch (e) {
    reveal();
  }
})();

document.addEventListener("DOMContentLoaded", async () => {
  const sunIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"></path></svg>`;
  const moonIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path></svg>`;
  const themeToggle = document.getElementById("themeToggle");
  const linkRedirectBtn = document.getElementById("linkRedirectBtn");
  if (linkRedirectBtn) {
    linkRedirectBtn.addEventListener("click", () => {
      window.location.href = "linkredirect.html";
    });
  }
  function logActivity() {}
  function updateThemeIcon(isLight) {
    if (themeToggle) themeToggle.innerHTML = isLight ? moonIcon : sunIcon;
  }
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([ "isLightMode" ], res => {
      if (res && res.isLightMode) {
        document.body.classList.add("light-mode");
        updateThemeIcon(true);
      } else {
        updateThemeIcon(false);
      }
    });
  }
  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      document.body.classList.toggle("light-mode");
      const isLightMode = document.body.classList.contains("light-mode");
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({
          isLightMode: isLightMode
        });
      }
      updateThemeIcon(isLightMode);
    });
  }
  const toggleFixTab = document.getElementById("toggleFixTab");
  const toggleFakeRef = document.getElementById("toggleFakeRef");
  const toggleLensPC = document.getElementById("toggleLensPC");
  const toggleLensPE = document.getElementById("toggleLensPE");
  const toggleUiFixer = document.getElementById("toggleUiFixer");
  const clearHistoryCard = document.getElementById("clearHistoryCard");
  const toggleClearHistory = document.getElementById("toggleClearHistory");
  const clearBtn = document.getElementById("clearBtn");
  const pinFloatBtn = document.getElementById("pinFloatBtn");
  const timePeriodLabels = document.querySelectorAll(".time-period-options label");
  const timePeriodInputs = document.querySelectorAll('input[name="popupTimePeriod"]');
  const floatbtnSizeSection = document.getElementById("floatbtnSizeSection");
  const floatbtnSizeRange = document.getElementById("floatbtnSizeRange");
  const floatbtnSizeVal = document.getElementById("floatbtnSizeVal");
  const FLOAT_SIZE_DEFAULT = 40;
  const TRASH_ICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:13px;height:13px;flex-shrink:0"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6M14 11v6"></path><path d="M9 6V4h6v2"></path></svg>`;
  const DONE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width:13px;height:13px;flex-shrink:0"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
  function updateClearHistoryEnabled(enabled) {
    if (clearHistoryCard) clearHistoryCard.classList.toggle("disabled", !enabled);
    if (toggleClearHistory) toggleClearHistory.checked = !!enabled;
  }
  function updatePinUI(pinned) {
    if (pinFloatBtn) pinFloatBtn.classList.toggle("active", !!pinned);
    if (floatbtnSizeSection) floatbtnSizeSection.classList.toggle("visible", !!pinned);
  }
  function setSelectedTimePeriod(value) {
    timePeriodLabels.forEach(lbl => {
      const input = lbl.querySelector('input[type="radio"]');
      if (!input) return;
      const match = input.value === value;
      input.checked = match;
      lbl.classList.toggle("selected", match);
    });
  }
  timePeriodLabels.forEach(lbl => {
    lbl.addEventListener("click", () => {
      const input = lbl.querySelector('input[type="radio"]');
      if (!input) return;
      setSelectedTimePeriod(input.value);
      chrome.storage.local.set({
        timePeriod: input.value
      });
    });
  });
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([ "clearHistoryEnabled", "timePeriod", "floatbtn", "floatbtnSize" ], res => {
      updateClearHistoryEnabled(!!res.clearHistoryEnabled);
      setSelectedTimePeriod(res.timePeriod || "last_hour");
      updatePinUI(!!res.floatbtn);
      const sz = Number(res.floatbtnSize) || FLOAT_SIZE_DEFAULT;
      if (floatbtnSizeRange) floatbtnSizeRange.value = sz;
      if (floatbtnSizeVal) floatbtnSizeVal.textContent = sz;
    });
  }
  toggleClearHistory?.addEventListener("change", () => {
    const enabled = toggleClearHistory.checked;
    chrome.storage.local.set({
      clearHistoryEnabled: enabled
    });
    logActivity(`Clear History : ${enabled ? "BẬT" : "TẮT"}`);
    updateClearHistoryEnabled(enabled);
    if (!enabled) {
      chrome.storage.local.set({
        floatbtn: false
      });
      updatePinUI(false);
    }
  });
  function getSelectedTimePeriod() {
    for (let i = 0; i < timePeriodInputs.length; i++) {
      if (timePeriodInputs[i].checked) return timePeriodInputs[i].value;
    }
    return "last_hour";
  }
  clearBtn?.addEventListener("click", () => {
    const timePeriod = getSelectedTimePeriod();
    chrome.storage.local.set({
      timePeriod: timePeriod
    });
    logActivity(`Clear History : Đã xoá (${timePeriod})`);
    clearBtn.classList.add("completed");
    clearBtn.innerHTML = DONE_ICON + " Done";
    setTimeout(() => {
      clearBtn.classList.remove("completed");
      clearBtn.innerHTML = TRASH_ICON + " Clear";
    }, 1200);
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, tabs => {
      chrome.runtime.sendMessage({
        action: "clearHistory",
        tab: tabs[0],
        timePeriod: timePeriod
      });
    });
  });
  pinFloatBtn?.addEventListener("click", () => {
    chrome.storage.local.get([ "floatbtn" ], data => {
      const newValue = !data.floatbtn;
      chrome.storage.local.set({
        floatbtn: newValue
      });
      updatePinUI(newValue);
      logActivity(`Ghim nút nổi (Clear History) : ${newValue ? "BẬT" : "TẮT"}`);
    });
  });
  const urlTriggerBtn = document.getElementById("urlTriggerBtn");
  const urlTriggerSection = document.getElementById("urlTriggerSection");
  const urlTriggerInput = document.getElementById("urlTriggerInput");
  const urlTriggerModeButtons = document.querySelectorAll("#urlTriggerModeSegmented .seg-btn");
  const urlTriggerAddBtn = document.getElementById("urlTriggerAddBtn");
  const urlTriggerList = document.getElementById("urlTriggerList");
  const urlTriggerEmpty = document.getElementById("urlTriggerEmpty");
  const toggleAutoCloseUrl = document.getElementById("toggleAutoCloseUrl");
  const autoCloseDelayInput = document.getElementById("autoCloseDelayInput");
  let selectedUrlTriggerMode = "contains";
  urlTriggerModeButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      selectedUrlTriggerMode = btn.dataset.mode === "exact" ? "exact" : "contains";
      urlTriggerModeButtons.forEach(b => b.classList.toggle("active", b === btn));
    });
  });
  const TRASH_SMALL_ICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6M14 11v6"></path><path d="M9 6V4h6v2"></path></svg>`;
  function normalizeUrlList(urls) {
    const list = Array.isArray(urls) ? urls : [];
    return list.map(item => {
      if (typeof item === "string") return {
        url: item,
        mode: "contains"
      };
      if (item && typeof item.url === "string") {
        return {
          url: item.url,
          mode: item.mode === "exact" ? "exact" : "contains"
        };
      }
      return null;
    }).filter(Boolean);
  }
  function renderUrlTriggerList(urls) {
    if (!urlTriggerList) return;
    const list = normalizeUrlList(urls);
    urlTriggerList.innerHTML = "";
    if (!list.length) {
      const empty = document.createElement("div");
      empty.className = "url-trigger-empty";
      empty.id = "urlTriggerEmpty";
      empty.textContent = "Chưa có URL nào được cài đặt.";
      urlTriggerList.appendChild(empty);
      return;
    }
    list.forEach(entry => {
      const item = document.createElement("div");
      item.className = "url-trigger-item";
      const span = document.createElement("span");
      span.textContent = entry.url;
      span.title = entry.url;
      const badge = document.createElement("span");
      badge.className = "url-trigger-mode-badge";
      badge.textContent = entry.mode === "exact" ? "Đúng" : "Chứa";
      badge.title = entry.mode === "exact" ? "Khớp đúng hoàn toàn" : "Khớp kiểu chứa chuỗi";
      const removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.title = "Xóa URL này";
      removeBtn.innerHTML = TRASH_SMALL_ICON;
      removeBtn.addEventListener("click", () => {
        chrome.storage.local.get([ "clearHistoryUrls" ], res => {
          const cur = normalizeUrlList(res.clearHistoryUrls);
          const next = cur.filter(u => !(u.url === entry.url && u.mode === entry.mode));
          chrome.storage.local.set({
            clearHistoryUrls: next
          });
          renderUrlTriggerList(next);
          logActivity(`Xóa URL tự động (Clear History) : ${entry.url}`);
        });
      });
      item.appendChild(span);
      item.appendChild(badge);
      item.appendChild(removeBtn);
      urlTriggerList.appendChild(item);
    });
  }
  urlTriggerBtn?.addEventListener("click", () => {
    const willShow = !urlTriggerSection?.classList.contains("visible");
    urlTriggerSection?.classList.toggle("visible", willShow);
    urlTriggerBtn.classList.toggle("active", willShow);
  });
  function addUrlTrigger() {
    const raw = (urlTriggerInput?.value || "").trim();
    if (!raw) return;
    const mode = selectedUrlTriggerMode === "exact" ? "exact" : "contains";
    chrome.storage.local.get([ "clearHistoryUrls" ], res => {
      const cur = normalizeUrlList(res.clearHistoryUrls);
      if (cur.some(u => u.url === raw && u.mode === mode)) {
        if (urlTriggerInput) urlTriggerInput.value = "";
        return;
      }
      const next = [ ...cur, {
        url: raw,
        mode: mode
      } ];
      chrome.storage.local.set({
        clearHistoryUrls: next
      });
      renderUrlTriggerList(next);
      logActivity(`Thêm URL tự động xóa lịch sử : ${raw} (${mode === "exact" ? "khớp đúng hoàn toàn" : "chứa chuỗi"})`);
      if (urlTriggerInput) urlTriggerInput.value = "";
    });
  }
  urlTriggerAddBtn?.addEventListener("click", addUrlTrigger);
  urlTriggerInput?.addEventListener("keydown", e => {
    if (e.key === "Enter") addUrlTrigger();
  });
  toggleAutoCloseUrl?.addEventListener("change", () => {
    const enabled = toggleAutoCloseUrl.checked;
    chrome.storage.local.set({
      autoCloseOnUrlMatch: enabled
    });
    logActivity(`Tự đóng tab khi khớp URL : ${enabled ? "BẬT" : "TẮT"}`);
  });
  autoCloseDelayInput?.addEventListener("change", () => {
    let val = parseInt(autoCloseDelayInput.value, 10);
    if (isNaN(val) || val < 0) val = 0;
    if (val > 300) val = 300;
    autoCloseDelayInput.value = val;
    chrome.storage.local.set({
      autoCloseDelaySeconds: val
    });
    logActivity(`Thời gian chờ trước khi tự đóng tab : ${val} giây`);
  });
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([ "clearHistoryUrls", "autoCloseOnUrlMatch", "autoCloseDelaySeconds" ], res => {
      renderUrlTriggerList(res.clearHistoryUrls || []);
      if (toggleAutoCloseUrl) toggleAutoCloseUrl.checked = !!res.autoCloseOnUrlMatch;
      if (autoCloseDelayInput) autoCloseDelayInput.value = res.autoCloseDelaySeconds !== undefined ? res.autoCloseDelaySeconds : 0;
    });
  }
  floatbtnSizeRange?.addEventListener("input", () => {
    const sz = Number(floatbtnSizeRange.value);
    if (floatbtnSizeVal) floatbtnSizeVal.textContent = sz;
    chrome.storage.local.set({
      floatbtnSize: sz
    });
  });
  floatbtnSizeRange?.addEventListener("change", () => {
    logActivity(`Tuỳ chỉnh kích thước nút nổi : ${floatbtnSizeRange.value}px`);
  });
  function schedulePageReload() {
    chrome.runtime.sendMessage({
      action: "scheduleReload"
    });
  }
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    const toggleAutoCaptcha = document.getElementById("toggleAutoCaptcha");
    chrome.storage.local.get([ "fixTab", "fakeRef", "lensPC", "lensPE", "uiFixer", "autoCaptcha" ], res => {
      if (toggleFixTab) toggleFixTab.checked = !!(res && res.fixTab);
      if (toggleFakeRef) toggleFakeRef.checked = !!(res && res.fakeRef);
      if (toggleLensPC) toggleLensPC.checked = !!(res && res.lensPC);
      if (toggleLensPE) toggleLensPE.checked = !!(res && res.lensPE);
      if (toggleUiFixer) toggleUiFixer.checked = !!(res && res.uiFixer);
      if (toggleAutoCaptcha) toggleAutoCaptcha.checked = !!(res && res.autoCaptcha);
    });
    const TOGGLE_LABELS = {
      fixTab: "Fix Countdown",
      fakeRef: "Google Referrer",
      lensPC: "Google Lens PC",
      lensPE: "Google Lens PE",
      uiFixer: "UI Fixer",
      autoCaptcha: "Auto Captcha"
    };
    const queueReloadOnToggle = (key, checked) => {
      chrome.storage.local.set({
        [key]: checked
      });
      logActivity(`${TOGGLE_LABELS[key] || key} : ${checked ? "BẬT" : "TẮT"}`);
      schedulePageReload();
    };
    toggleFixTab?.addEventListener("change", e => queueReloadOnToggle("fixTab", e.target.checked));
    toggleFakeRef?.addEventListener("change", e => queueReloadOnToggle("fakeRef", e.target.checked));
    toggleLensPC?.addEventListener("change", e => queueReloadOnToggle("lensPC", e.target.checked));
    toggleLensPE?.addEventListener("change", e => queueReloadOnToggle("lensPE", e.target.checked));
    toggleUiFixer?.addEventListener("change", e => queueReloadOnToggle("uiFixer", e.target.checked));
    toggleAutoCaptcha?.addEventListener("change", e => queueReloadOnToggle("autoCaptcha", e.target.checked));
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  const autoClickToggle = document.getElementById("autoClickToggle");
  if (autoClickToggle && typeof chrome !== "undefined" && chrome.storage) {
    chrome.storage.local.get([ "autoClickEnabled" ], res => {
      autoClickToggle.checked = !!(res && res.autoClickEnabled);
    });
    autoClickToggle.addEventListener("change", e => {
      const enabled = e.target.checked;
      chrome.storage.local.set({
        autoClickEnabled: enabled
      });
      logActivity(`Auto Click : ${enabled ? "BẬT" : "TẮT"}`);
    });
  }
  async function initMyScriptsList() {
    const msList = document.getElementById("myscriptsList");
    const msEmpty = document.getElementById("myscriptsEmpty");
    const msAddBtn = document.getElementById("msAddBtn");
    if (!msList || typeof chrome === "undefined" || !chrome.storage) return;
    const EDIT_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>`;
    const DELETE_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>`;
    const RESTORE_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>`;
    const MAX_HISTORY = 30;
    async function getDeletedScripts() {
      const {deletedScripts: deletedScripts = []} = await chrome.storage.local.get("deletedScripts");
      return deletedScripts;
    }
    async function saveDeletedScripts(deletedScripts) {
      await chrome.storage.local.set({
        deletedScripts: deletedScripts
      });
    }
    async function getMsScripts() {
      const {scripts: scripts = []} = await chrome.storage.local.get("scripts");
      return scripts;
    }
    async function saveMsScripts(scripts) {
      await chrome.storage.local.set({
        scripts: scripts
      });
    }
    function renderMsScripts(scripts) {
      msList.innerHTML = "";
      if (!scripts.length) {
        msEmpty.style.display = "block";
        msList.style.display = "none";
        return;
      }
      msEmpty.style.display = "none";
      msList.style.display = "block";
      scripts.forEach(script => {
        const row = document.createElement("div");
        row.className = "myscripts-item";
        row.innerHTML = `\n          <label class="switch"><input type="checkbox" data-id="${script.id}" class="ms-toggle" ${script.enabled ? "checked" : ""}><span class="slider"></span></label>\n          <span class="myscripts-item-name" title="${escapeHtml(script.name)}">${escapeHtml(script.name)}</span>\n          <button class="myscripts-icon-btn ms-edit" data-id="${script.id}" title="Sửa">${EDIT_ICON}</button>\n          <button class="myscripts-icon-btn danger ms-delete" data-id="${script.id}" title="Xóa">${DELETE_ICON}</button>\n        `;
        msList.appendChild(row);
      });
      msList.querySelectorAll(".ms-toggle").forEach(el => {
        el.addEventListener("change", async e => {
          const id = e.target.dataset.id;
          const scripts = await getMsScripts();
          const s = scripts.find(s => s.id === id);
          if (!s) return;
          s.enabled = e.target.checked;
          await saveMsScripts(scripts);
          logActivity(`Userscript "${s.name}" : ${s.enabled ? "BẬT" : "TẮT"}`);
          chrome.runtime.sendMessage({
            type: "RELOAD_MATCHING_TABS",
            matches: s.matches
          });
        });
      });
      msList.querySelectorAll(".ms-edit").forEach(el => {
        el.addEventListener("click", async e => {
          const id = e.currentTarget.dataset.id;
          let originTabId = "";
          try {
            const [activeTab] = await chrome.tabs.query({
              active: true,
              currentWindow: true
            });
            if (activeTab?.id) originTabId = activeTab.id;
          } catch (e) {}
          chrome.tabs.create({
            url: `myscripts_editor.html?id=${id}${originTabId ? `&originTabId=${originTabId}` : ""}`
          });
        });
      });
      msList.querySelectorAll(".ms-delete").forEach(el => {
        el.addEventListener("click", async e => {
          const id = e.currentTarget.dataset.id;
          if (!confirm("Xóa script này? (Vẫn có thể khôi phục lại trong mục Lịch sử)")) return;
          let scripts = await getMsScripts();
          const removed = scripts.find(s => s.id === id);
          scripts = scripts.filter(s => s.id !== id);
          await saveMsScripts(scripts);
          if (removed) {
            let deleted = await getDeletedScripts();
            deleted.unshift({
              ...removed,
              deletedAt: Date.now()
            });
            if (deleted.length > MAX_HISTORY) deleted = deleted.slice(0, MAX_HISTORY);
            await saveDeletedScripts(deleted);
            logActivity(`Userscript "${removed.name}" : Đã xoá (chuyển vào Lịch sử)`);
          }
          renderMsScripts(scripts);
        });
      });
    }
    const msHistoryBtn = document.getElementById("msHistoryBtn");
    const msHistorySection = document.getElementById("msHistorySection");
    const msHistoryList = document.getElementById("msHistoryList");
    const msHistoryEmpty = document.getElementById("msHistoryEmpty");
    function renderMsHistory(deletedScripts) {
      if (!msHistoryList) return;
      msHistoryList.innerHTML = "";
      if (!deletedScripts.length) {
        msHistoryEmpty.style.display = "block";
        msHistoryList.style.display = "none";
        return;
      }
      msHistoryEmpty.style.display = "none";
      msHistoryList.style.display = "block";
      deletedScripts.forEach(script => {
        const row = document.createElement("div");
        row.className = "myscripts-item";
        row.innerHTML = `\n          <span class="myscripts-item-name" title="${escapeHtml(script.name)}">${escapeHtml(script.name)}</span>\n          <button class="myscripts-icon-btn ms-restore" data-id="${script.id}" title="Khôi phục">${RESTORE_ICON}</button>\n          <button class="myscripts-icon-btn danger ms-purge" data-id="${script.id}" title="Xoá vĩnh viễn">${DELETE_ICON}</button>\n        `;
        msHistoryList.appendChild(row);
      });
      msHistoryList.querySelectorAll(".ms-restore").forEach(el => {
        el.addEventListener("click", async e => {
          const id = e.currentTarget.dataset.id;
          let deleted = await getDeletedScripts();
          const restored = deleted.find(s => s.id === id);
          if (!restored) return;
          deleted = deleted.filter(s => s.id !== id);
          await saveDeletedScripts(deleted);
          const {deletedAt: deletedAt, ...scriptData} = restored;
          const scripts = await getMsScripts();
          scripts.push(scriptData);
          await saveMsScripts(scripts);
          logActivity(`Userscript "${restored.name}" : Đã khôi phục từ Lịch sử`);
          renderMsScripts(scripts);
          renderMsHistory(deleted);
        });
      });
      msHistoryList.querySelectorAll(".ms-purge").forEach(el => {
        el.addEventListener("click", async e => {
          const id = e.currentTarget.dataset.id;
          if (!confirm("Xoá vĩnh viễn script này? Sẽ KHÔNG thể khôi phục lại được nữa.")) return;
          let deleted = await getDeletedScripts();
          const purged = deleted.find(s => s.id === id);
          deleted = deleted.filter(s => s.id !== id);
          await saveDeletedScripts(deleted);
          if (purged) logActivity(`Userscript "${purged.name}" : Đã xoá vĩnh viễn khỏi Lịch sử`);
          renderMsHistory(deleted);
        });
      });
    }
    msHistoryBtn?.addEventListener("click", async () => {
      const willShow = !msHistorySection.classList.contains("visible");
      msHistorySection.classList.toggle("visible", willShow);
      msHistoryBtn.classList.toggle("active", willShow);
      if (willShow) renderMsHistory(await getDeletedScripts());
    });
    msAddBtn?.addEventListener("click", async () => {
      let originTabId = "";
      try {
        const [activeTab] = await chrome.tabs.query({
          active: true,
          currentWindow: true
        });
        if (activeTab?.id) originTabId = activeTab.id;
      } catch (e) {}
      chrome.tabs.create({
        url: `myscripts_editor.html${originTabId ? `?originTabId=${originTabId}` : ""}`
      });
    });
    renderMsScripts(await getMsScripts());
  }
  initMyScriptsList();

  // ========== Lười Auto Login ==========
  (function initLuoiLogin() {
    const emailInput = document.getElementById("luoiEmail");
    const passwordInput = document.getElementById("luoiPassword");
    const otpInput = document.getElementById("luoiOtp");
    const autoSubmitCheckbox = document.getElementById("luoiAutoSubmit");
    const loginBtn = document.getElementById("luoiLoginBtn");
    const statusEl = document.getElementById("luoiStatus");

    if (!emailInput || !passwordInput || !loginBtn) return;

    const LOGIN_URL = "https://cryptolinkforearn.com/login";
    let saveTimeout = null;

    // Load dữ liệu đã lưu
    chrome.storage.local.get(
      ["luoi_email", "luoi_password", "luoi_otp", "luoi_autoSubmit"],
      (data) => {
        if (data.luoi_email) emailInput.value = data.luoi_email;
        if (data.luoi_password) passwordInput.value = data.luoi_password;
        if (data.luoi_otp) otpInput.value = data.luoi_otp;
        if (typeof data.luoi_autoSubmit === "boolean") {
          autoSubmitCheckbox.checked = data.luoi_autoSubmit;
        }
      }
    );

    function showStatus(msg, type = "success") {
      statusEl.textContent = msg;
      statusEl.className = "luoi-status " + type;
      setTimeout(() => {
        statusEl.textContent = "";
        statusEl.className = "luoi-status";
      }, 2500);
    }

    async function saveCredentials() {
      const email = emailInput.value.trim();
      const password = passwordInput.value;
      const otp = otpInput.value.trim();
      const autoSubmit = autoSubmitCheckbox.checked;

      try {
        await chrome.storage.local.set({
          luoi_email: email,
          luoi_password: password,
          luoi_otp: otp,
          luoi_autoSubmit: autoSubmit,
        });
        return true;
      } catch (e) {
        console.error(e);
        return false;
      }
    }

    function scheduleSave() {
      if (saveTimeout) clearTimeout(saveTimeout);
      saveTimeout = setTimeout(async () => {
        const ok = await saveCredentials();
        if (ok) showStatus("✓ Đã tự động lưu", "success");
      }, 400);
    }

    emailInput.addEventListener("input", scheduleSave);
    passwordInput.addEventListener("input", scheduleSave);
    otpInput.addEventListener("input", scheduleSave);
    autoSubmitCheckbox.addEventListener("change", async () => {
      const ok = await saveCredentials();
      if (ok) showStatus("✓ Đã tự động lưu", "success");
    });

    loginBtn.addEventListener("click", async () => {
      const email = emailInput.value.trim();
      const password = passwordInput.value;

      if (!email || !password) {
        showStatus("Vui lòng nhập email và mật khẩu!", "error");
        return;
      }

      loginBtn.disabled = true;
      loginBtn.textContent = "Đang mở...";

      try {
        const ok = await saveCredentials();
        if (!ok) {
          showStatus("Lỗi lưu dữ liệu", "error");
          return;
        }

        await chrome.tabs.create({ url: LOGIN_URL });
        showStatus("✓ Đã mở trang login", "success");
        window.close();
      } catch (e) {
        console.error(e);
        showStatus("Lỗi mở trang", "error");
      } finally {
        loginBtn.disabled = false;
        loginBtn.textContent = "Đăng nhập ngay";
      }
    });
  })();

  // ========== Limit List (từ Shizuka) ==========
  (function initLimitList() {
    const card = document.getElementById("limitCard");
    const header = document.getElementById("limitHeader");
    const textarea = document.getElementById("limitListTextarea");
    const saveBtn = document.getElementById("limitSaveBtn");
    const toggleModeBtn = document.getElementById("limitToggleModeBtn");
    const descLabel = document.getElementById("limitDescLabel");
    const statusEl = document.getElementById("limitStatus");
    const countEl = document.getElementById("limitCount");

    if (!card || !textarea || !saveBtn) return;

    let inputMode = "link"; // "link" | "code"

    function extractCodeFromLink(raw) {
      const G = (raw || "").trim();
      if (!G) return "";
      try {
        if (G.startsWith("http://") || G.startsWith("https://")) {
          const u = new URL(G);
          const parts = u.pathname.split("/").filter((p) => p.trim().length > 0);
          if (u.hostname.includes("linkhuongdan.online") && parts[0]) return parts[0];
          return parts[0] || "";
        }
        const cleaned = G.replace(/^(https?:\/\/)?(www\.)?/, "");
        const parts = cleaned.split("/").filter((p) => p.trim().length > 0);
        if (parts[0] && parts[0].includes("linkhuongdan.online") && parts[1]) return parts[1];
        return parts[0] || "";
      } catch (e) {
        const m = G.match(/linkhuongdan\.online\/([^\/\s\?]+)/);
        if (m) return m[1];
        return G;
      }
    }

    function isValidCode(code) {
      // Cho phép "199-2" hoặc chỉ "199" (khớp mọi 199-x)
      return /^\d+(-\d+)?$/.test(code || "");
    }

    function showStatus(msg, type = "success") {
      statusEl.textContent = msg;
      statusEl.className = "limit-status " + type;
      setTimeout(() => {
        statusEl.textContent = "";
        statusEl.className = "limit-status";
      }, 2500);
    }

    function fillTextarea(list) {
      if (inputMode === "link") {
        descLabel.textContent = "Nhập các đường link (mỗi dòng 1 link):";
        toggleModeBtn.textContent = "ĐỔI: NHẬP MÃ";
        textarea.value = (list || []).map((c) => "https://linkhuongdan.online/" + c + "/").join("\n");
        textarea.placeholder = "https://linkhuongdan.online/236-2/";
      } else {
        descLabel.textContent = "Nhập các mã (ngăn cách bằng dấu ;):";
        toggleModeBtn.textContent = "ĐỔI: NHẬP LINK";
        textarea.value = (list || []).join("; ");
        textarea.placeholder = "218-2; 221-2; 120-3";
      }
    }

    function updateCount(list) {
      countEl.textContent = String((list || []).length);
    }

    chrome.storage.local.get(
      ["limitList", "limitInputMode"],
      (data) => {
        inputMode = data.limitInputMode === "code" ? "code" : "link";
        const list = Array.isArray(data.limitList) ? data.limitList : [];
        fillTextarea(list);
        updateCount(list);
      }
    );

    header.addEventListener("click", () => {
      card.classList.toggle("open");
    });

    toggleModeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const raw = textarea.value;
      let list = [];
      if (inputMode === "link") {
        list = raw
          .split("\n")
          .map((l) => extractCodeFromLink(l.trim()))
          .filter((c) => c.length > 0);
        inputMode = "code";
      } else {
        list = raw
          .split(";")
          .map((c) => c.trim())
          .filter((c) => c.length > 0);
        inputMode = "link";
      }
      chrome.storage.local.set({ limitInputMode: inputMode });
      fillTextarea(list);
    });

    saveBtn.addEventListener("click", () => {
      const raw = textarea.value.trim();
      let codes = [];

      if (raw) {
        if (inputMode === "link") {
          const lines = raw.split("\n").map((l) => l.trim()).filter((l) => l.length > 0);
          for (const line of lines) {
            const looksLikeUrl =
              line.startsWith("http://") ||
              line.startsWith("https://") ||
              line.includes("linkhuongdan.online") ||
              (line.includes(".") && line.includes("/"));
            if (!looksLikeUrl) {
              showStatus("Link không hợp lệ: " + line, "error");
              return;
            }
            const code = extractCodeFromLink(line);
            if (!isValidCode(code)) {
              showStatus("Mã không hợp lệ (vd: 199 hoặc 199-2): " + line, "error");
              return;
            }
            codes.push(code);
          }
        } else {
          const parts = raw.split(";").map((c) => c.trim()).filter((c) => c.length > 0);
          for (const c of parts) {
            if (!isValidCode(c)) {
              showStatus("Mã không hợp lệ: " + c + " (vd: 199 hoặc 199-2)", "error");
              return;
            }
            codes.push(c);
          }
        }
        if (codes.length === 0) {
          showStatus("Không tìm thấy mã hợp lệ!", "error");
          return;
        }
      }

      codes = [...new Set(codes)];

      chrome.storage.local.get(["limitList"], (prev) => {
        const oldList = prev.limitList || [];
        const same =
          oldList.length === codes.length &&
          [...oldList].sort().every((v, i) => v === [...codes].sort()[i]);

        if (same) {
          showStatus("Danh sách limit đã được lưu trước đó", "success");
          return;
        }

        chrome.storage.local.set(
          { limitList: codes, limitInputMode: inputMode },
          () => {
            updateCount(codes);
            fillTextarea(codes);
            showStatus("✓ Đã lưu " + codes.length + " mã giới hạn", "success");
            const oldText = saveBtn.textContent;
            saveBtn.textContent = "SAVED!";
            setTimeout(() => {
              saveBtn.textContent = oldText;
            }, 1000);
          }
        );
      });
    });

    textarea.addEventListener("keydown", (e) => {
      if ((e.key === "Enter" || e.keyCode === 13) && !e.shiftKey && inputMode === "code") {
        e.preventDefault();
        saveBtn.click();
      }
    });
  })();
});

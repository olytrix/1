/**
 * Limit Skip — cơ chế đúng:
 * octolink.vip/xxx → redirect ra mã trong Limit List → quay lại link gốc → thử lại
 * Lặp vô hạn đến khi ra mã KHÔNG nằm trong list.
 */
(function () {
  "use strict";
  if (window !== window.top) return;

  const STORAGE_LIMIT = "limitList";
  const STORAGE_BACK = "lastOctoLink";
  const DEFAULT_BACK = "https://octolink.vip";
  const SKIP_DELAY_MS = 350;

  // Chỉ chống bắn nhiều lần trong CÙNG một lần load trang (không dùng sessionStorage)
  let skipScheduledFor = "";
  let lastCheckedUrl = "";

  function extractCode(pathname) {
    const parts = (pathname || "").split("/").filter((p) => p.trim().length > 0);
    if (!parts.length) return "";
    // Ưu tiên segment dạng 199-2 hoặc 199
    for (const p of parts) {
      if (/^\d+(-\d+)?$/.test(p)) return p;
    }
    return parts[0] || "";
  }

  function isLimited(code, limitList) {
    if (!code || !limitList || !limitList.length) return false;
    const c = String(code).trim();
    for (const raw of limitList) {
      const entry = String(raw || "").trim();
      if (!entry) continue;
      if (c === entry) return true;
      // "199" khớp "199-2"
      if (/^\d+$/.test(entry) && (c === entry || c.startsWith(entry + "-"))) return true;
      // "199-2" khớp code bắt đầu "199-2"
      if (c.startsWith(entry + "-") || entry.startsWith(c + "-")) return true;
    }
    return false;
  }

  function isOctoLinkUrl(href) {
    try {
      const u = new URL(href, location.href);
      if (!/octolink/i.test(u.hostname)) return false;
      const path = u.pathname || "";
      if (path.length <= 1 || path === "/") return false;
      if (/\/finish\//i.test(path)) return false;
      return true;
    } catch (e) {
      return false;
    }
  }

  function saveLastOctoLink(href) {
    if (!isOctoLinkUrl(href)) return;
    chrome.storage.local.set({ [STORAGE_BACK]: href.split("#")[0] });
  }

  // Lưu khi đang đứng trên octolink
  if (isOctoLinkUrl(location.href)) {
    saveLastOctoLink(location.href);
  }

  // Lưu khi click link octolink
  document.addEventListener(
    "mousedown",
    (e) => {
      const a = e.target && e.target.closest ? e.target.closest("a") : null;
      if (a && a.href) saveLastOctoLink(a.href);
    },
    true
  );

  // Bắt cả click (một số site không mousedown đủ)
  document.addEventListener(
    "click",
    (e) => {
      const a = e.target && e.target.closest ? e.target.closest("a") : null;
      if (a && a.href) saveLastOctoLink(a.href);
    },
    true
  );

  function goBack(back) {
    let target = back || DEFAULT_BACK;
    if (/\/finish\//i.test(target)) target = DEFAULT_BACK;

    // Thêm cache-bust nhẹ để octolink cấp mã mới (không phá path)
    try {
      const u = new URL(target);
      u.searchParams.set("_noo", String(Date.now()));
      target = u.toString();
    } catch (e) {
      target =
        target + (target.indexOf("?") >= 0 ? "&" : "?") + "_noo=" + Date.now();
    }

    console.log("[Noo Limit] → quay về", target);
    location.replace(target);
  }

  function trySkipLimitedCode(reason) {
    const href = location.href;
    const host = location.hostname || "";

    // Đang ở octolink / google → chỉ lưu link, không skip
    if (/octolink/i.test(host)) {
      if (isOctoLinkUrl(href)) saveLastOctoLink(href);
      return;
    }
    if (/google\.com/i.test(host) || /kiemgao\.site/i.test(host)) return;

    // Đã schedule skip cho đúng URL này trong lần load hiện tại
    if (skipScheduledFor === href) return;

    const code = extractCode(location.pathname);
    if (!code) return;
    // Chỉ xử lý khi path trông giống mã nhiệm vụ
    if (!/^\d+(-\d+)?$/.test(code) && !/^\d+-\d+/.test(code)) return;

    chrome.storage.local.get([STORAGE_LIMIT, STORAGE_BACK], (data) => {
      // URL có thể đã đổi trong lúc chờ storage
      if (location.href !== href) return;

      const list = data[STORAGE_LIMIT] || [];
      if (!list.length) return;
      if (!isLimited(code, list)) {
        console.log("[Noo Limit] Mã OK, giữ trang:", code);
        return;
      }

      let back = data[STORAGE_BACK] || DEFAULT_BACK;
      // Fallback: document.referrer nếu là octolink
      if ((!back || back === DEFAULT_BACK) && document.referrer && isOctoLinkUrl(document.referrer)) {
        back = document.referrer;
      }

      skipScheduledFor = href;
      console.log(
        "[Noo Limit] Skip mã",
        code,
        "| lý do:",
        reason || "check",
        "| về:",
        back
      );

      setTimeout(function () {
        goBack(back);
      }, SKIP_DELAY_MS);
    });
  }

  function onReady() {
    trySkipLimitedCode("ready");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", onReady);
  } else {
    onReady();
  }

  // Theo dõi đổi URL (redirect / SPA / history)
  setInterval(function () {
    if (location.href === lastCheckedUrl) return;
    lastCheckedUrl = location.href;
    // URL mới = cho phép skip lại (reset guard của URL cũ)
    skipScheduledFor = "";
    if (isOctoLinkUrl(location.href)) {
      saveLastOctoLink(location.href);
    }
    setTimeout(function () {
      trySkipLimitedCode("url-change");
    }, 150);
  }, 300);

  // Bắt pushState / replaceState
  try {
    const wrap = function (type) {
      const orig = history[type];
      return function () {
        const ret = orig.apply(this, arguments);
        setTimeout(function () {
          skipScheduledFor = "";
          trySkipLimitedCode("history-" + type);
        }, 100);
        return ret;
      };
    };
    history.pushState = wrap("pushState");
    history.replaceState = wrap("replaceState");
    window.addEventListener("popstate", function () {
      skipScheduledFor = "";
      setTimeout(function () {
        trySkipLimitedCode("popstate");
      }, 100);
    });
  } catch (e) {}
})();

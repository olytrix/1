/**
 * Auto Canvas Anti-Captcha (port từ userscript)
 * Chạy MAIN world + document_start khi toggle bật.
 * Giữ chấm đen, simulate human move, auto click "Thử lại".
 */
(function () {
  "use strict";
  if (window.__nooAutoCaptchaInstalled) return;
  window.__nooAutoCaptchaInstalled = true;

  const W = window;

  // Force open shadow roots (để query canvas trong captcha)
  try {
    const origAttach = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (init) {
      return origAttach.call(this, Object.assign({}, init || {}, { mode: "open" }));
    };
  } catch (e) {}

  // isTrusted luôn true (một số captcha check)
  try {
    const desc = Object.getOwnPropertyDescriptor(Event.prototype, "isTrusted");
    if (desc) {
      Object.defineProperty(Event.prototype, "isTrusted", {
        get: function () {
          return true;
        },
      });
    }
  } catch (e) {}

  // Bắt tọa độ chấm đen qua arc()
  W.__nooCapX = 0;
  W.__nooCapY = 0;
  try {
    const origArc = CanvasRenderingContext2D.prototype.arc;
    CanvasRenderingContext2D.prototype.arc = function (x, y, r) {
      if (r > 15 && r < 25) {
        W.__nooCapX = x;
        W.__nooCapY = y;
      }
      return origArc.apply(this, arguments);
    };
  } catch (e) {}

  function startLoop() {
    let state = false; // false | 'waiting' | true
    let curX = 0;
    let curY = 0;
    let tick = 0;

    const badge = document.createElement("div");
    badge.style.cssText =
      'position:fixed;bottom:20px;left:20px;background:rgba(10,10,10,0.85);backdrop-filter:blur(5px);color:#4ade80;padding:8px 16px;border-radius:20px;font-family:"Segoe UI",system-ui,monospace;font-size:12px;font-weight:bold;z-index:2147483647;display:none;border:1px solid #4ade80;box-shadow:0 4px 15px rgba(0,0,0,0.5);pointer-events:none;transition:opacity 0.3s ease;';
    (document.body || document.documentElement).appendChild(badge);

    function showBadge(html, color) {
      badge.style.display = "block";
      badge.style.opacity = "1";
      badge.style.color = color;
      badge.style.borderColor = color;
      badge.innerHTML = html;
    }
    function hideBadge() {
      badge.style.opacity = "0";
      setTimeout(function () {
        badge.style.display = "none";
      }, 300);
    }

    function fire(el, type, x, y) {
      try {
        el.dispatchEvent(
          new PointerEvent(type.replace("mouse", "pointer"), {
            bubbles: true,
            cancelable: true,
            clientX: x,
            clientY: y,
            pointerId: 1,
            isPrimary: true,
            button: 0,
            buttons: 1,
          })
        );
        el.dispatchEvent(
          new MouseEvent(type, {
            bubbles: true,
            cancelable: true,
            clientX: x,
            clientY: y,
            view: W,
            button: 0,
            buttons: 1,
          })
        );
      } catch (e) {}
    }

    function findCanvas() {
      let c = document.querySelector("canvas");
      if (c) return c;
      const host = document.querySelector("#captchaShortlink");
      if (host && host.children.length > 0) {
        const child = host.children[0];
        if (child && child.shadowRoot) {
          c = child.shadowRoot.querySelector("canvas");
        }
      }
      return c || null;
    }

    function frame() {
      const canvas = findCanvas();
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        if (state === false) {
          state = "waiting";
          showBadge("⏳ Phát hiện Canvas! Đang tạo độ trễ...", "#facc15");
          try {
            canvas.scrollIntoView({ behavior: "smooth", block: "center" });
          } catch (e) {}
          setTimeout(function () {
            curX = rect.left + rect.width / 2 + (Math.random() * 6 - 3);
            curY = rect.top + rect.height / 2 + (Math.random() * 6 - 3);
            fire(canvas, "mousedown", curX, curY);
            state = true;
          }, 400 + Math.random() * 400);
        } else if (state === true && W.__nooCapX > 0 && W.__nooCapY > 0) {
          tick++;
          showBadge("🎯 Đang giữ chấm đen (Human Mode)...", "#4ade80");
          const tx = rect.left + W.__nooCapX * (rect.width / 504);
          const ty = rect.top + W.__nooCapY * (rect.height / 430);
          const jx = Math.sin(tick * 0.15) * 2 + (Math.random() - 0.5);
          const jy = Math.cos(tick * 0.11) * 2 + (Math.random() - 0.5);
          const ease = 0.35 + Math.random() * 0.05;
          curX += (tx + jx - curX) * ease;
          curY += (ty + jy - curY) * ease;
          fire(canvas, "mousemove", curX, curY);
        }
      } else {
        if (state === true || state === "waiting") {
          state = false;
          W.__nooCapX = 0;
          W.__nooCapY = 0;
          showBadge("✔ Xử lý Canvas thành công.", "#60a5fa");
          setTimeout(hideBadge, 2500);
        }
      }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);

    // Auto bấm "Thử lại" / "vui lòng thử lại"
    setInterval(function () {
      const nodes = document.querySelectorAll("button, span, div, a");
      for (let i = 0; i < nodes.length; i++) {
        const el = nodes[i];
        const t = el.innerText ? el.innerText : "";
        if (t === "Thử lại" || t.toLowerCase().includes("vui lòng thử lại")) {
          showBadge("⚠ Trượt mục tiêu! Đang tự động thử lại...", "#f87171");
          try {
            el.click();
          } catch (e) {}
          state = false;
          W.__nooCapX = 0;
          W.__nooCapY = 0;
        }
      }
    }, 1500);
  }

  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", startLoop);
  } else {
    startLoop();
  }
})();

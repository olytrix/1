window.addEventListener("message", event => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.__nooGmXhrRequest !== true) return;
  chrome.runtime.sendMessage({
    type: "GM_XHR",
    payload: data
  }, resp => {
    const err = chrome.runtime.lastError;
    const result = resp || {
      error: err ? err.message : "Không có phản hồi"
    };
    window.postMessage({
      __nooGmXhrResponse: true,
      id: data.id,
      ...result
    }, "*");
  });
});

(function() {
  "use strict";
  const AC_STATE_KEY = "acState";
  const DEFAULT_SELECTORS = [ {
    selector: "svg-btn",
    intervalMs: 1500
  } ];
  const DEFAULT_RELOAD_RULES = [ {
    w: 300,
    h: 48,
    wCmp: "gt",
    hCmp: "eq",
    count: 1
  } ];
  const RELOAD_POLL_MS = 200;
  let autoClickEnabled = false;
  let acSelectors = DEFAULT_SELECTORS;
  let acReloadRules = DEFAULT_RELOAD_RULES;
  window.addEventListener("message", event => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.type !== "CLICK") return;
    if (data.eventType !== "MOUSE_PRESS" && data.eventType !== "MOUSE_RELEASE") return;
    if (!autoClickEnabled) {
      window.postMessage({
        type: "CLICK_RESULT",
        ok: false
      }, "*");
      return;
    }
    try {
      const runtimeType = data.eventType === "MOUSE_PRESS" ? "AC_MOUSE_PRESS" : "AC_MOUSE_RELEASE";
      chrome.runtime.sendMessage({
        type: runtimeType,
        x: data.x,
        y: data.y
      }, response => {
        window.postMessage({
          type: "CLICK_RESULT",
          ok: !chrome.runtime.lastError && !!(response && response.ok)
        }, "*");
      });
    } catch (e) {
      window.postMessage({
        type: "CLICK_RESULT",
        ok: false
      }, "*");
    }
  });
  window.postMessage({
    type: "CLICK_READY"
  }, "*");
  function clickButtonsMatching(selector) {
    let els;
    try {
      els = document.querySelectorAll(selector);
    } catch (e) {
      return;
    }
    els.forEach(b => {
      const r = b.getBoundingClientRect();
      const x = r.left + r.width / 2;
      const y = r.top + r.height / 2;
      window.postMessage({
        type: "CLICK",
        eventType: "MOUSE_PRESS",
        x: x,
        y: y
      }, "*");
      setTimeout(() => window.postMessage({
        type: "CLICK",
        eventType: "MOUSE_RELEASE",
        x: x,
        y: y
      }, "*"), 50);
      [ "mousedown", "mouseup", "click" ].forEach(t => {
        b.dispatchEvent(new MouseEvent(t, {
          view: window,
          bubbles: true,
          cancelable: true,
          clientX: x,
          clientY: y,
          button: 0
        }));
      });
    });
  }
  let clickTimers = [];
  function startClickTimers() {
    stopClickTimers();
    const rows = acSelectors && acSelectors.length ? acSelectors : DEFAULT_SELECTORS;
    rows.forEach(row => {
      const selector = row && row.selector;
      let intervalMs = row && Number(row.intervalMs);
      if (!Number.isFinite(intervalMs) || intervalMs < 100) intervalMs = 1500;
      if (!selector) return;
      clickTimers.push(setInterval(() => clickButtonsMatching(selector), intervalMs));
    });
  }
  function stopClickTimers() {
    clickTimers.forEach(t => clearInterval(t));
    clickTimers = [];
  }
  window.startAutoClick = () => {
    if (autoClickEnabled) startClickTimers();
  };
  window.stopAutoClick = stopClickTimers;
  function normalizeCmp(v) {
    return v === "lt" ? "lt" : v === "eq" ? "eq" : "gt";
  }
  function matchAxis(value, threshold, cmp) {
    if (cmp === "lt") return value < threshold;
    if (cmp === "eq") return Math.round(value) === threshold;
    return value > threshold;
  }
  function ruleMatches(rule, width, height) {
    return matchAxis(width, rule.w, rule.wCmp) && matchAxis(height, rule.h, rule.hCmp);
  }
  function ruleSelector(rule) {
    return rule && rule.selector && String(rule.selector).trim() ? String(rule.selector).trim() : "svg-btn";
  }
  function ruleKey(rule, idx) {
    return `nooAcReloadCount_${idx}_${rule.w}x${rule.h}_${rule.wCmp}_${rule.hCmp}_${ruleSelector(rule)}`;
  }
  function getRuleCount(key) {
    try {
      const v = Number(sessionStorage.getItem(key));
      return Number.isFinite(v) && v > 0 ? v : 0;
    } catch (e) {
      return 0;
    }
  }
  function setRuleCount(key, n) {
    try {
      sessionStorage.setItem(key, String(n));
    } catch (e) {}
  }
  function clearRuleCount(key) {
    try {
      sessionStorage.removeItem(key);
    } catch (e) {}
  }
  let reloadTimer = null;
  function checkButtonsForReload() {
    if (!autoClickEnabled) return;
    const matchedNow = new Set;
    const rules = acReloadRules && acReloadRules.length ? acReloadRules : DEFAULT_RELOAD_RULES;
    for (let i = 0; i < rules.length; i++) {
      const rule = rules[i];
      let btns;
      try {
        btns = document.querySelectorAll(ruleSelector(rule));
      } catch (e) {
        continue;
      }
      for (const btn of btns) {
        const rect = btn.getBoundingClientRect();
        if (!ruleMatches(rule, rect.width, rect.height)) continue;
        const key = ruleKey(rule, i);
        matchedNow.add(key);
        const done = getRuleCount(key);
        if (done < rule.count) {
          setRuleCount(key, done + 1);
          location.reload();
          return;
        }
        break;
      }
    }
    rules.forEach((rule, i) => {
      const key = ruleKey(rule, i);
      if (!matchedNow.has(key)) clearRuleCount(key);
    });
  }
  function startReloadPolling() {
    if (reloadTimer) return;
    reloadTimer = setInterval(checkButtonsForReload, RELOAD_POLL_MS);
  }
  function stopReloadPolling() {
    if (reloadTimer) {
      clearInterval(reloadTimer);
      reloadTimer = null;
    }
  }
  function sanitizeSelectors(list) {
    if (!Array.isArray(list)) return null;
    const out = [];
    list.forEach(item => {
      if (!item || !item.selector) return;
      let intervalMs = Math.round(Number(item.intervalMs));
      if (!Number.isFinite(intervalMs) || intervalMs < 100) intervalMs = 1500;
      out.push({
        selector: String(item.selector),
        intervalMs: intervalMs
      });
    });
    return out.length ? out : null;
  }
  function sanitizeReloadRules(list) {
    if (!Array.isArray(list)) return null;
    const out = [];
    list.forEach(item => {
      if (!item) return;
      const w = Math.round(Number(item.w));
      const h = Math.round(Number(item.h));
      const wCmp = normalizeCmp(item.wCmp);
      const hCmp = normalizeCmp(item.hCmp);
      let count = Math.round(Number(item.count));
      if (!Number.isFinite(count) || count < 1) count = 1;
      const selector = typeof item.selector === "string" && item.selector.trim() ? item.selector.trim() : "";
      if (Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0) out.push({
        w: w,
        h: h,
        wCmp: wCmp,
        hCmp: hCmp,
        count: count,
        selector: selector
      });
    });
    return out.length ? out : null;
  }
  function applyState(enabled, state) {
    autoClickEnabled = !!enabled;
    acSelectors = sanitizeSelectors(state && state.selectors) || DEFAULT_SELECTORS;
    acReloadRules = sanitizeReloadRules(state && state.reloadRules) || DEFAULT_RELOAD_RULES;
    if (autoClickEnabled) {
      startClickTimers();
      startReloadPolling();
    } else {
      stopClickTimers();
      stopReloadPolling();
    }
  }
  try {
    chrome.storage.local.get([ "autoClickEnabled", AC_STATE_KEY ], res => {
      applyState(res && res.autoClickEnabled, res && res[AC_STATE_KEY]);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (!("autoClickEnabled" in changes) && !(AC_STATE_KEY in changes)) return;
      chrome.storage.local.get([ "autoClickEnabled", AC_STATE_KEY ], res => {
        applyState(res && res.autoClickEnabled, res && res[AC_STATE_KEY]);
      });
    });
  } catch (e) {}
})();

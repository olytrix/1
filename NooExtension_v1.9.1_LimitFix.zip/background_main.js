import "./background.js";

try {
  if (typeof chrome !== "undefined" && chrome.scripting && chrome.scripting.unregisterContentScripts) {
    chrome.scripting.unregisterContentScripts().catch(() => {});
  }
} catch (e) {}

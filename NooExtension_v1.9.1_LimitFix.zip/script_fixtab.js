(() => {
  console.log("[Extension] Fix Tab Activated");
  document.addEventListener("visibilitychange", function(e) {
    e.stopImmediatePropagation();
  }, true);
  try {
    Object.defineProperty(document, "hidden", {
      get: () => false,
      configurable: true
    });
  } catch (e) {}
  try {
    Object.defineProperty(document, "visibilityState", {
      get: () => "visible",
      configurable: true
    });
  } catch (e) {}
  document.hasFocus = () => true;
  window.onblur = null;
  window.blur = () => {};
})();

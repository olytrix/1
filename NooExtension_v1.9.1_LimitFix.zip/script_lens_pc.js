(() => {
  "use strict";
  function openLens(img) {
    const src = img.currentSrc || img.src;
    if (!src || src.startsWith("data:")) return;
    window.open("https://lens.google.com/uploadbyurl?url=" + encodeURIComponent(src), "_blank");
  }
  document.addEventListener("contextmenu", e => {
    const img = e.target.closest("img");
    if (!img) return;
    e.preventDefault();
    openLens(img);
  }, true);
})();
